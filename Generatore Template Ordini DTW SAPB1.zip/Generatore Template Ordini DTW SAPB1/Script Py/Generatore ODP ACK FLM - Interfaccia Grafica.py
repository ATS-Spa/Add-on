# Generatore ORDR Repairer Ack - ATS.py
import os
import sys
import gzip
import shutil
import pandas as pd
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime
from threading import Thread
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import logging

# ========================
# 0. Cartella base
# ========================
if getattr(sys, "frozen", False):
    base_path = os.path.dirname(sys.executable)
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

log_path = os.path.join(base_path, "Repairer_Ack_Log.txt")
db_path = os.path.join(base_path, "Database_Generatore.db")
output_folder = os.path.join(base_path, "DTW_Repairer_Ack_Output")
os.makedirs(output_folder, exist_ok=True)

# ========================
# Logger GUI + File
# ========================
class GUILogger:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.log_file = open(log_path, "a", encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[logging.StreamHandler(self)])
    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)
        self.log_file.write(message)
        self.log_file.flush()
    def flush(self): pass

# ========================
# GUI
# ========================
root = tk.Tk()
root.title("Generatore ODP - Repairer Ack Received")
root.geometry("840x700")
root.resizable(False, False)
root.configure(bg="#f0f4f8")

style = ttk.Style()
style.theme_use('clam')

tk.Label(root, text="GENERATORE ODP REPAIRER ACK", font=("Segoe UI", 20, "bold"), bg="#f0f4f8", fg="#2c3e50").pack(pady=(25, 8))
tk.Label(root, text="Seleziona il file FR.CSV o FR.CSV.GZ", font=("Segoe UI", 10), bg="#f0f4f8", fg="#7f8c8d").pack(pady=(0, 20))

frame = tk.Frame(root, bg="#f0f4f8")
frame.pack(pady=10, padx=35, fill="both", expand=True)

btn_scegli = tk.Button(frame, text="SCEGLI FILE FR.CSV / FR.CSV.GZ", font=("Segoe UI", 11, "bold"), width=42, height=2, bg="#3498db", fg="white", relief="flat", cursor="hand2")
btn_scegli.pack(pady=15)

lbl_file = tk.Label(frame, text="Nessun file selezionato", font=("Segoe UI", 10), bg="#f0f4f8", fg="#95a5a6", wraplength=740)
lbl_file.pack(pady=(5, 15))

progress = ttk.Progressbar(frame, mode='determinate', length=740)
progress.pack(pady=10)

log_frame = tk.Frame(frame, bg="white", relief="sunken", bd=1)
log_frame.pack(pady=15, fill="both", expand=True)
log_text = tk.Text(log_frame, height=18, font=("Consolas", 9), bg="#fdfdfd", fg="#2c3e50", wrap="word")
log_text.pack(side="left", fill="both", expand=True, padx=5, pady=5)
scrollbar = tk.Scrollbar(log_frame, command=log_text.yview)
scrollbar.pack(side="right", fill="y")
log_text.config(yscrollcommand=scrollbar.set)

footer = tk.Label(root, text=f"Output: {output_folder} | DB: Database_Generatore.db | Log: Repairer_Ack_Log.txt",
                  font=("Segoe UI", 8), bg="#f0f4f8", fg="#95a5a6")
footer.pack(side="bottom", pady=15)

csv_path = None
logger = None

# ========================
# INVIO MAIL
# ========================
def invia_email_smtp(filepath, to="atssegnalazioni@gmail.com"):
    msg = MIMEMultipart()
    msg['From'] = "atssegnalazioni@gmail.com"
    msg['To'] = to
    msg['Subject'] = f"FR Da Definire - Repairer Ack - {datetime.now():%d/%m/%Y}"
    with open(filepath, "rb") as f:
        part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
        msg.attach(part)
    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("atssegnalazioni@gmail.com", "xxx")
            server.send_message(msg)
        print("Email 'Da Definire' inviata")
        return True
    except Exception as e:
        print(f"Errore invio email: {e}")
        return False

# ========================
# COLONNE DTW - ORDR / RDR1
# ========================
ordr_columns = [
    "DocNum","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode","CardName","Address","NumAtCard","DocCur","DocRate","DocTotal","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt","SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply",
    "ObjType","ShipToCode","Indicator","LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate","CancelDate",
    "BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn","Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref","FolioNum","DocSubType","BPChCode","BPChCntc",
    "Address2","PayToCode","ManualNumber","UseShpdGd","IsPaytoBnk","BnkCntry","BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode",
    "TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model","UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC",
    "VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount","InsurOp347","IgnRelDoc","U_Tipo"
]

rdr1_columns = [
    "ParentKey","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT","Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SubCatNum","OcrCode","Project","CodeBars","VatGroup","Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4","BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag","ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","ShipToCode","RowTotalFC","CFOPCode","CSTCode","Usage","TaxOnly","UnitPrice","LineStatus","LineType",
    "COGSCostingCode","COGSAccountCode","ChangeAssemlyBoMWarehouse","GrossBuyPrice","GrossBase","GrossProfitTotalBasePrice","CostingCode2","CostingCode3","CostingCode4","CostingCode5",
    "ItemDetails","LocationCode","ActualDeliveryDate","ExLineNo","RequiredDate","RequiredQuantity","COGSCostingCode2","COGSCostingCode3","COGSCostingCode4","COGSCostingCode5",
    "WithoutInventoryMovement","AgrementNo","AgreementRowNumber","ShipToDescription","U_PartNumber","U_CDC","U_IDScheda","U_Location","U_PO","U_Posizione","U_ReqDate","U_TargaSito",
    "U_Seriale","U_MOLO"
]

ordr_header_sap = [
    "DocNum","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode","CardName","Address","NumAtCard","DocCur","DocRate","DocTotal","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt","SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply",
    "ObjType","ShipToCode","Indicator","LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate","CancelDate",
    "BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn","Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref","FolioNum","DocSubType","BPChCode","BPChCntc",
    "Address2","PayToCode","ManualNumber","UseShpdGd","IsPaytoBnk","BnkCntry","BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode",
    "TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model","UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC",
    "VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount","InsurOp347","IgnRelDoc","U_Tipo"
]

rdr1_header_sap = [
    "DocNum","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT","Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SupplierCatNum","OcrCode","Project","CodeBars","VatGroup","Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4","BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag","ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","ShipToCode","TotalFrgn","CFOPCode","CSTCode","Usage","TaxOnly","PriceBefDi","LineStatus","LineType",
    "CogsOcrCod","CogsAcct","ChgAsmBoMW","GrossBuyPr","GrossBase","GPTtlBasPr","OcrCode2","OcrCode3","OcrCode4","OcrCode5","Text","LocCode","ActDelDate","ExLineNo","PQTReqDate",
    "PQTReqQty","CogsOcrCo2","CogsOcrCo3","CogsOcrCo4","CogsOcrCo5","NoInvtryMv","AgrNo","AgrLnNum","ShipToDesc","U_PartNumber","U_CDC","U_IDScheda","U_Location","U_PO","U_Posizione",
    "U_ReqDate","U_TargaSito","U_Seriale","U_MOLO"
]

# ========================
# ELABORAZIONE
# ========================
def avvia_elaborazione():
    global csv_path, logger
    if not csv_path:
        messagebox.showerror("Errore", "Seleziona un file!")
        return

    logger = GUILogger(log_text)
    sys.stdout = logger
    log_text.delete(1.0, tk.END)

    def run():
        conn = None
        try:
            progress['value'] = 0
            root.update()

            # Decompressione
            if csv_path.endswith(".gz"):
                temp_path = os.path.join(base_path, "fr_temp.csv")
                with gzip.open(csv_path, "rb") as f_in, open(temp_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
                csv_local = temp_path
            else:
                csv_local = csv_path

            print(f"Lettura file: {os.path.basename(csv_local)}")
            progress['value'] = 10
            root.update()

            df = pd.read_csv(csv_local, sep="|", engine="python", dtype=str, keep_default_na=False, quoting=3,on_bad_lines="warn",usecols=range(57))
            print(f"Righe totali: {len(df)}")

            df["stato"] = df["stato"].astype(str).str.strip()
            df["advanced_swap"] = df["advanced_swap"].astype(str).str.strip()

            mask = (
                (df["stato"] == "Repairer Ack Received") |
                ((df["stato"] == "Failed Material Received and Verify") & (df["advanced_swap"] == "Y"))
            )
            df = df[mask].copy()
            print(f"Righe dopo filtro: {len(df)}")
            if df.empty:
                messagebox.showinfo("Info", "Nessuna riga da elaborare.")
                return

            progress['value'] = 20
            root.update()

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ordr_out = os.path.join(output_folder, f"ORDR_RepairerAck_{timestamp}.csv")
            rdr1_out = os.path.join(output_folder, f"RDR1_RepairerAck_{timestamp}.csv")
            da_definire_out = os.path.join(output_folder, f"FR_Da_Definire_RepairerAck_{timestamp}.csv")

            conn = sqlite3.connect(db_path)
            storico_table = "StoricoOrdiniCaricati_Repairer"
            conn.execute(f'''CREATE TABLE IF NOT EXISTS "{storico_table}" ("FR" TEXT PRIMARY KEY, "TimeStamp" TEXT)''')
            conn.commit()

            storico_fr = pd.read_sql_query(f'SELECT FR FROM "{storico_table}"', conn)["FR"].astype(str).str.strip().tolist()
            df = df[~df["fr_id"].astype(str).str.strip().isin(storico_fr)]
            print(f"Righe nuove da elaborare: {len(df)}")
            if df.empty:
                messagebox.showinfo("Info", "Tutte le righe sono già state elaborate.")
                return

            conv_depositi = pd.read_sql_query('SELECT * FROM "Conversione Depositi VLT"', conn).fillna("")
            anagrafica = pd.read_sql_query('SELECT * FROM "Anagrafica_SAP" WHERE "Codice articolo (ATS)" LIKE "%-FLM"', conn).fillna("")

            progress['value'] = 40
            root.update()

            # === PREPARAZIONE DATI (100% sicura) ===
            df["depot_origine"] = df["depot_origine"].astype(str).str.strip().str.upper()
            conv_depositi["VLT"] = conv_depositi["VLT"].astype(str).str.strip().str.upper()

            df = df.merge(conv_depositi[["VLT", "nome_dtw", "codice_dtw"]], how="left", left_on="depot_origine", right_on="VLT")

            df["codice_dtw"] = df["codice_dtw"].fillna("NON DEFINITO").astype(str).str.strip()
            df["nome_dtw"]  = df["nome_dtw"].fillna("NON DEFINITO").astype(str).str.strip()

            df["U_Mittente"] = df["codice_dtw"].replace(["0", "", "NAN"], "NON DEFINITO")
            df["U_NomeMitt"] = df["nome_dtw"]

            df["riparatore"] = df["riparatore"].astype(str).str.strip().str.upper()
            mappa_riparatore = dict(zip(conv_depositi["CONVERSIONE_RIPARATORE"].astype(str).str.strip().str.upper(), conv_depositi["codice_dtw"]))
            df["U_Riparatore"] = df["riparatore"].map(mappa_riparatore).fillna("NON DEFINITO")

            df["f_mat_material"] = df["f_mat_material"].astype(str).str.strip()
            df = df.merge(anagrafica[["Codice articolo (ATS)", "Material SAP Code (BP)"]], how="left", left_on="f_mat_material", right_on="Material SAP Code (BP)")
            df["ItemCode"] = df["Codice articolo (ATS)"].fillna("DA DEFINIRE")

            df.drop(columns=["VLT", "nome_dtw", "codice_dtw"], errors="ignore", inplace=True)

            progress['value'] = 60
            root.update()

            # === ELABORAZIONE FINALE ===
            ordr_list = []
            rdr1_list = []
            da_definire_list = []
            docnum = 10001

            for _, row in df.iterrows():
                fr_id = str(row["fr_id"]).strip()

                ordr_row = {c: "" for c in ordr_columns}
                ordr_row.update({
                    "DocNum": docnum, "DocType": "dDocument_Items", "DocDate": datetime.today().strftime("%Y%m%d"),
                    "DocDueDate": datetime.today().strftime("%Y%m%d"), "CardCode": "F000263", "NumAtCard": fr_id,
                    "Series": 237, "ShipToCode": row["U_Riparatore"] if row["U_Riparatore"] != "NON DEFINITO" else "" ,
                    "TaxDate": datetime.today().strftime("%Y%m%d"), "Project": "FLM",
                    "U_Tipo": "FR", "Comments": "Repairer Ack Received"
                })

                rdr1_row = {c: "" for c in rdr1_columns}
                rdr1_row.update({
                    "ParentKey": docnum, "LineNum": 0, "ItemCode": row["ItemCode"], "Quantity": 1,
                    "WhsCode": "CE71-INC", "SubCatNum": str(row.get("f_mat_material", "")).strip().upper(), "Project": "FLM", 
                    "U_PartNumber": str(row.get("f_mat_tmpn", "")).strip().upper(),
                    "U_PO": fr_id, "U_CDC": 1, "Price": 0,
                    "U_IDScheda": str(row.get("f_mat_serial_no", "")).strip().upper(),
                    "U_Seriale": str(row.get("f_mat_serial_no", "")).strip().upper(),
                    "U_MOLO":row["U_Riparatore"] if row["U_Riparatore"] != "NON DEFINITO" else ""
                })

                errors = []
                if row["ItemCode"] == "DA DEFINIRE":
                    errors.append(f"Item non mappato: {row['f_mat_material']}")
                if row["U_Mittente"] == "NON DEFINITO":
                    errors.append(f"Mittente non trovato: {row.get('depot_origine', '???')}")

                if errors:
                    rdr1_row["Motivo_Errore"] = " | ".join(errors)
                    da_definire_list.append({**ordr_row, **rdr1_row})
                else:
                    ordr_list.append(ordr_row)
                    rdr1_list.append(rdr1_row)
                    conn.execute(f'INSERT OR IGNORE INTO "{storico_table}" (FR, TimeStamp) VALUES (?, ?)',
                                 (fr_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                    conn.commit()

                docnum += 1
                progress['value'] = 60 + (docnum - 10001) / len(df) * 35
                root.update_idletasks()

            # === SCRITTURA FILE ===
            def write_dtw(data_list, path, header_sap, columns):
                if not data_list:
                    print(f"Nessuna riga per {os.path.basename(path)}")
                    return
                with open(path, "w", encoding="utf-8", newline="") as f:
                    f.write(",".join(header_sap) + "\n")
                    f.write(",".join(columns) + "\n")
                    pd.DataFrame(data_list, columns=columns).to_csv(f, index=False, header=False, lineterminator="\n")

            write_dtw(ordr_list, ordr_out, ordr_header_sap, ordr_columns)
            write_dtw(rdr1_list, rdr1_out, rdr1_header_sap, rdr1_columns)

            if da_definire_list:
                all_columns = list(da_definire_list[0].keys())
                pd.DataFrame(da_definire_list, columns=all_columns).to_csv(
                    da_definire_out, index=False, sep=",", encoding="utf-8-sig"
                )
                print(f"Generato Da Definire: {da_definire_out}")
                invia_email_smtp(da_definire_out)

            print(f"\nDTW creati con successo!\nORDR → {ordr_out}\nRDR1 → {rdr1_out}")
            progress['value'] = 100
            messagebox.showinfo("Completato", f"Elaborazione terminata!\nCartella: {output_folder}")

        except Exception as e:
            messagebox.showerror("ERRORE", str(e))
            logging.exception(e)
        finally:
            if conn: conn.close()

    Thread(target=run, daemon=True).start()

def scegli_file():
    global csv_path
    file = filedialog.askopenfilename(filetypes=[("CSV", "*.csv *.csv.gz"), ("Tutti", "*.*")])
    if file:
        csv_path = file
        lbl_file.config(text=f"File: {os.path.basename(file)}", fg="#27ae60")
        btn_scegli.config(text="AVVIA ELABORAZIONE", command=avvia_elaborazione, bg="#27ae60")

btn_scegli.config(command=scegli_file)
root.mainloop()