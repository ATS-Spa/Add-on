# Launcher_GUI.py - VERSIONE 2.5 - SINISTRA + MASSIMO IN ALTO
import tkinter as tk
from tkinter import messagebox, ttk
import subprocess
import sys
from pathlib import Path
import os
import threading

# === RISOLUZIONE PERCORSO ===
if getattr(sys, 'frozen', False):
    SCRIPT_DIR = Path(sys.executable).parent
else:
    SCRIPT_DIR = Path(__file__).parent

# === CONFIGURAZIONE STRUMENTI ===
STRUMENTI = {
    "Generatore ODA NTD": "Generatore ODA NTD.exe",
    "Generatore ODP NTD": "Generatore ODP NTD.exe",
    "Generatore EM ODR NTD": "Generatore EM ODR NTD.exe",
    "Generatore ODA FLM": "Generatore ODA FLM.exe",
    "Generatore ODP 'RMA' FLM": "Generatore ODP FLM.exe",
    "Generatore ODP 'ACK' FLM": "Generatore ODP ACK FLM.exe",
    "​Aggiornamento Anagrafica Database": "AGGIORNAMENTO ANAGRAFICA DATABASE.exe"
}

# === FUNZIONE ESECUZIONE ===
def esegui_strumento(nome_strumento):
    file_exe = SCRIPT_DIR / STRUMENTI[nome_strumento]
    
    if not file_exe.exists():
        messagebox.showerror("File Mancante", f"Non trovo:\n{file_exe.name}")
        return

    root.withdraw()

    def run():
        try:
            process = subprocess.Popen([str(file_exe)], cwd=SCRIPT_DIR, creationflags=subprocess.CREATE_NEW_CONSOLE)
            process.wait()
            root.after(0, lambda: messagebox.showinfo("Completato!", f"{nome_strumento}\nterminato."))
        except Exception as e:
            root.after(0, lambda: messagebox.showerror("Errore", f"{e}"))
        finally:
            root.after(0, root.deiconify)

    threading.Thread(target=run, daemon=True).start()

# === GUI ===
root = tk.Tk()
root.title("Launcher Strumenti Aziendali")
root.geometry("560x950")
root.resizable(False, False)
root.configure(bg="#f4f6f9")

# === POSIZIONE: SINISTRA + MASSIMO IN ALTO ===
def position_top_left():
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = 0  # Sinistra dello schermo
    y = 0  # Massimo in alto (0 px dal bordo)
    root.geometry(f"{width}x{height}+{x}+{y}")

position_top_left()  # <--- APPLICATA

style = ttk.Style()
style.theme_use('clam')

# Titolo
tk.Label(root, text="STRUMENTI AZIENDALI", font=("Segoe UI", 20, "bold"), bg="#f4f6f9", fg="#2c3e50").pack(pady=(30, 20))
tk.Label(root, text="Seleziona lo strumento da eseguire", font=("Segoe UI", 10), bg="#f4f6f9", fg="#7f8c8d").pack(pady=(0, 30))

frame = tk.Frame(root, bg="#f4f6f9")
frame.pack(pady=10)

for nome, filename in STRUMENTI.items():
    esiste = (SCRIPT_DIR / filename).exists()
    
    btn = tk.Button(
        frame,
        text=nome,
        font=("Segoe UI", 11, "bold"),
        width=46,
        height=2,
        bg="#3498db" if esiste else "#95a5a6",
        fg="white",
        activebackground="#2980b9" if esiste else "#7f8c8d",
        relief="flat",
        cursor="hand2" if esiste else "arrow",
        command=lambda n=nome: esegui_strumento(n)
    )
    btn.pack(pady=6)

    tk.Label(
        frame,
        text="TROVATO" if esiste else "MANCANTE ... IN FASE DI SVILUPPO",
        font=("Segoe UI", 8),
        fg="#27ae60" if esiste else "#e74c3c",
        bg="#f4f6f9"
    ).pack(pady=(0, 8))

# Footer
tk.Label(
    root,
    text="Strumento per la creazione di Template DTW SAPB1 ATS S.p.A\n"
         "Versione 2.5 | © 2025 - Strumenti Aziendali",
    font=("Segoe UI", 8),
    bg="#f4f6f9",
    fg="#95a5a6",
    justify="center"
).pack(side="bottom", pady=10)

root.mainloop()