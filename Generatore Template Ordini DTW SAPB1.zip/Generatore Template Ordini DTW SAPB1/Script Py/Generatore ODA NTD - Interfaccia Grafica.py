import pandas as pd
from datetime import datetime
import os
import sys
import logging
import zipfile
import win32com.client
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import sqlite3
import tkinter as tk
from tkinter import filedialog
import shutil
import gzip
# ========================
# 0. Setup Logging
# ========================
logfile = "ODA_NTD_Log.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(logfile, mode="a", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)

# ========================
# 1. Cartella base
# ========================
if getattr(sys, "frozen", False):
    base_path = os.path.dirname(os.path.abspath(sys.executable))
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

output_folder = os.path.join(base_path, "DTWOrdiniAcquistoOutputNTD")
os.makedirs(output_folder, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
opor_out = os.path.join(output_folder, f"OPOR_{timestamp}.csv")
por1_out = os.path.join(output_folder, f"POR1_{timestamp}.csv")
da_definire_out = os.path.join(output_folder, f"PO_Da_Definire_{timestamp}.csv")

# ========================
# 2. SELEZIONE MANUALE DEL FILE CSV O .GZ
# ========================
root = tk.Tk()
root.withdraw()  # Nasconde la finestra principale

logging.info("Apertura finestra di selezione file...")
print("\nSeleziona il file 'order_line_list.csv' o 'order_line_list.csv.gz'...")

file_path = filedialog.askopenfilename(
    title="Seleziona il file order_line_list.csv o .gz",
    initialdir=base_path,
    filetypes=[
        ("File CSV", "*.csv"),
        ("File compressi", "*.csv.gz"),
        ("Tutti i file", "*.*")
    ]
)

if not file_path:
    logging.error("Nessun file selezionato. Uscita.")
    print("Nessun file selezionato. Uscita.")
    input("\nPremi INVIO per chiudere...")
    sys.exit(1)

csv_path = file_path
logging.info(f"File selezionato: {csv_path}")
print(f"File selezionato: {csv_path}")

# ========================
# DECOMPRESSIONE SE .GZ
# ========================
if csv_path.endswith(".gz"):
    decompressed_path = os.path.join(base_path, "order_line_list_decompresso.csv")
    logging.info("Decompressione del file .gz in corso...")
    print("Decompressione del file .gz...")
    try:
        with gzip.open(csv_path, "rb") as f_in:
            with open(decompressed_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        csv_path = decompressed_path
        logging.info(f"Decompresso in: {csv_path}")
        print(f"Decompresso in: {csv_path}")
    except Exception as e:
        logging.error(f"Errore decompressione .gz: {e}")
        print(f"Errore decompressione: {e}")
        input("\nPremi INVIO per chiudere...")
        sys.exit(1)

# ========================
# NOTE: non usiamo più l'excel Storico&conversioniNTD.xlsx, usiamo database SQLite
# ========================
db_path = os.path.join(base_path, "Database_Generatore.db")

# ========================
# INVIO MAIL PER FILE NON DEFINITI
# ========================
def invia_email_smtp(filepath, to="dizzo@atsgruppo.eu"):
    msg = MIMEMultipart()
    msg['From'] = "atssegnalazioni@gmail.com"
    msg['To'] = to
    msg['Subject'] = f"PO Da Definire - {datetime.now():%d/%m/%Y}"

    with open(filepath, "rb") as f:
        part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
        msg.attach(part)

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("atssegnalazioni@gmail.com", "xxx")  # App Password
            server.send_message(msg)
        logging.info("Email inviata via Gmail SMTP")
        return True
    except Exception as e:
        logging.error(f"SMTP fallito: {e}")
        return False

# ========================
# 3. Leggi input CSV (ora da csv_path selezionato)
# ========================
try:
    df = pd.read_csv(csv_path, dtype=str, sep=";").fillna("")
    logging.info(f"Totale righe lette da OPEN PO NTD (CSV): {len(df)}")
    print(f"Lette {len(df)} righe dal file.")
except Exception as e:
    logging.error(f"Errore lettura CSV: {e}")
    print(f"Errore lettura file: {e}")
    input("\nPremi INVIO per chiudere...")
    sys.exit(1)

# ========================
# NORMALIZZAZIONE COLONNE
# ========================
df = df.rename(columns={
    "PO Number (Header)": "NumPO",
    "Order Date (Header)": "DataPO",
    "Qty": "Qta",
    "SAP Material Code": "CodiceMateriale",
    "Supplier": "NomeFornitore",
    "Need-By": "PrevCons",
    "Receiving Warehouse": "PODeliveryDate",
    "Plant (Header)": "Plant",
    "Line": "PosPO"
}, errors="ignore")

if "PODeliveryDate" not in df.columns:
    df["PODeliveryDate"] = ""

def convert_to_ddmmyyyy(d):
    if pd.isna(d) or str(d).strip() == "":
        return ""
    try:
        dt = pd.to_datetime(d, dayfirst=True, errors="coerce")
        if pd.isna(dt):
            return ""
        return dt.strftime("%d/%m/%Y")
    except Exception:
        return ""

for col in ["DataPO"]:
    df[col] = df[col].apply(convert_to_ddmmyyyy)

# ========================
# 3. Normalizza valori
# ========================
df["NumPO"] = df["NumPO"].astype(str).str.strip()
df["Qta"] = pd.to_numeric(df["Qta"], errors="coerce").fillna(0).astype(int)
df["CodiceMateriale"] = df["CodiceMateriale"].astype(str).str.strip()

# Salva copia del file usato per tracciabilità
copia_path = os.path.join(base_path, f"order_line_list_usato_{timestamp}.csv")
shutil.copy(csv_path, copia_path)
logging.info(f"Copia del file usato salvata: {copia_path}")

# ========================
# 4. Carica storico e lookup DAL DB SQLite (sostituisce openpyxl + pd.read_excel)
# ========================
# Connessione al DB
try:
    conn = sqlite3.connect(db_path)
    logging.info(f"Connessione aperta a: {db_path}")
except Exception as e:
    logging.error(f"Errore connessione a SQLite: {e}")
    raise

# Assicuriamoci che la tabella storico esista (crea se mancante)
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS StoricoOrdiniCaricatiNTD (
        NumPO TEXT,
        DataPO TEXT,
        Qta TEXT,
        CodiceMateriale TEXT,
        MaxLineNum INTEGER,
        DataCaricamento TEXT,
        group_key TEXT
    )
    """)
    conn.commit()
except Exception as e:
    logging.error(f"Errore creando/controllando tabella StoricoOrdiniCaricatiNTD: {e}")
    raise

# Legge lo storico esistente
try:
    storico_df = pd.read_sql_query("SELECT * FROM StoricoOrdiniCaricatiNTD;", conn).fillna("")
    logging.info(f"Righe già in storico: {len(storico_df)}")
except Exception as e:
    logging.error(f"Errore durante la lettura dello storico dal DB: {e}")
    storico_df = pd.DataFrame()

# Prepara set e dizionario come prima
max_linenum_dict = {}
storico_records = set()
if not storico_df.empty:
    for _, row in storico_df.iterrows():
        # replica la logica di controllo delle righe del foglio Excel
        if pd.notna(row.get("NumPO")) and pd.notna(row.get("DataPO")) and pd.notna(row.get("Qta")) and pd.notna(row.get("CodiceMateriale")):
            quintupla = (str(row["NumPO"]), str(row["DataPO"]), str(row["Qta"]), str(row["CodiceMateriale"]), str(row.get("group_key", "")))
            storico_records.add(quintupla)
        numpo = str(row["NumPO"])
        linenum = int(row["MaxLineNum"]) if row.get("MaxLineNum") not in (None, "") else 0
        max_linenum_dict[numpo] = max(max_linenum_dict.get(numpo, -1), linenum)

logging.info(f"Righe già in storico (set costruito): {len(storico_records)}")

# Lettura tabelle lookup dalla DB (sostituisce pd.read_excel)
try:
    conv_depositi = pd.read_sql_query("SELECT * FROM 'Conversione Depositi NSS';", conn).fillna("")
    # manteniamo lo stesso preprocessing
    if "CONVERSIONE_MITT" in conv_depositi.columns:
        conv_depositi["CONVERSIONE_MITT"] = conv_depositi["CONVERSIONE_MITT"].astype(str).str.strip().str.upper()
except Exception as e:
    logging.error(f"Errore leggendo 'Conversione Depositi NSS' da DB: {e}")
    conv_depositi = pd.DataFrame()

try:
    # FILTRA NELLA QUERY SQL: solo righe con "Codice Articolo (ATS)" che finisce con "-NTD"
    anagrafica = pd.read_sql_query("""
        SELECT * FROM "Anagrafica_SAP"
        WHERE "Codice Articolo (ATS)" LIKE '%-NTD'
    """, conn).fillna("")

    # Normalizza la colonna (se esiste)
    if "Material SAP Code (BP)" in anagrafica.columns:
        anagrafica["Material SAP Code (BP)"] = anagrafica["Material SAP Code (BP)"].astype(str).str.strip()

    logging.info(f"Anagrafica caricata con filtro -NTD: {len(anagrafica)} righe")
except Exception as e:
    logging.error(f"Errore leggendo 'Anagrafica_SAP' da DB: {e}")
    anagrafica = pd.DataFrame()
    
try:
    cdc_map = pd.read_sql_query("SELECT * FROM 'OPORCodificaCodSap';", conn).fillna("")
    if "NameCDC" in cdc_map.columns and "CodeCDC" in cdc_map.columns:
        cdc_dict = dict(zip(cdc_map["NameCDC"], cdc_map["CodeCDC"]))
    else:
        cdc_dict = {}
except Exception as e:
    logging.error(f"Errore leggendo 'OPORCodificaCodSap' da DB: {e}")
    cdc_map = pd.DataFrame()
    cdc_dict = {}

# ========================
# Funzioni di lookup
# ========================
def get_mittente(nome_fornitore):
    key = str(nome_fornitore).strip().upper()
    if not conv_depositi.empty and "CONVERSIONE_MITT" in conv_depositi.columns:
        row = conv_depositi[conv_depositi["CONVERSIONE_MITT"] == key]
        return row.iloc[0].get("nome_dtw", "NON DEFINITO") if not row.empty else "NON DEFINITO"
    return "NON DEFINITO"

def get_codemitt(nome_fornitore):
    key = str(nome_fornitore).strip().upper()
    if not conv_depositi.empty and "CONVERSIONE_MITT" in conv_depositi.columns:
        row = conv_depositi[conv_depositi["CONVERSIONE_MITT"] == key]
        return row.iloc[0].get("codice_dtw", "NON DEFINITO") if not row.empty else "NON DEFINITO"
    return "NON DEFINITO"

def get_itemcode(codice_materiale):
    if not anagrafica.empty and "Material SAP Code (BP)" in anagrafica.columns:
        row = anagrafica[anagrafica["Material SAP Code (BP)"] == codice_materiale]
        return row.iloc[0].get("Codice articolo (ATS)", "DA DEFINIRE") if not row.empty else "DA DEFINIRE"
    return "DA DEFINIRE"

def get_partnumber(codice_materiale):
    if not anagrafica.empty and "Material SAP Code (BP)" in anagrafica.columns:
        row = anagrafica[anagrafica["Material SAP Code (BP)"] == codice_materiale]
        return row.iloc[0].get("part number", "") if not row.empty else ""
    return ""

def get_cdc(plant):
    return cdc_dict.get(str(plant).strip(), "0")

# ========================
# 6. Costruzione OPOR / POR1
# ========================
opor_list, por1_list, da_definire_list = [], [], []
docNum = 1001

def build_opor_row(group_key, first_row, mittente, codemitt):
    docdate_csv = datetime.strptime(first_row["DataPO"], "%d/%m/%Y").strftime("%Y%m%d") if first_row["DataPO"] else datetime.today().strftime("%Y%m%d")
    docdue_csv = datetime.strptime(first_row["PrevCons"], "%d/%m/%Y").strftime("%Y%m%d") if first_row["PrevCons"] else \
                 datetime.strptime(first_row["PODeliveryDate"], "%d/%m/%Y").strftime("%Y%m%d") if first_row["PODeliveryDate"] else ""
    return {
        "DocNum": docNum,
        "DocEntry": "",
        "DocType": "dDocument_Items",
        "HandWritten":"",
        "Printed":"",
        "DocDate": docdate_csv,
        "DocDueDate": docdue_csv,
        "CardCode": "F000263",
        "CardName":"",
        "Address":"",
        "NumAtCard": first_row["NumPO"],
        "DocTotal":"",
        "AttachmentEntry":"",
        "DocCurrency":"",
        "DocRate":"",
        "Reference1":"",
        "Reference2":"",
        "Comments":"",
        "JournalMemo":"",
        "PaymentGroupCode":"",
        "DocTime":"",
        "SalesPersonCode":"",
        "TransportationCode":"",
        "Confirmed":"",
        "ImportFileNum":"",
        "SummeryType":"",
        "ContactPersonCode":"",
        "ShowSCN":"",
        "Series": 165,
        "TaxDate": docdate_csv,
        "PartialSupply":"",
        "DocObjectCode":"",
        "ShipToCode":"",
        "Indicator":"",
        "FederalTaxID":"",
        "DiscountPercent":"",
        "PaymentReference":"",
        "DocTotalFc":"",
        "Form1099":"",
        "Box1099":"",
        "RevisionPo":"",
        "RequriedDate":"",
        "CancelDate":"",
        "BlockDunning":"",
        "Pick":"",
        "PaymentMethod":"",
        "PaymentBlock":"",
        "PaymentBlockEntry":"",
        "CentralBankIndicator":"",
        "MaximumCashDiscount":"",
        "Project": "NTD",
        "ExemptionValidityDateFrom":"",
        "ExemptionValidityDateTo":"",
        "WareHouseUpdateType":"",
        "Rounding":"",
        "ExternalCorrectedDocNum":"",
        "InternalCorrectedDocNum":"",
        "DeferredTax":"",
        "TaxExemptionLetterNum":"",
        "AgentCode":"",
        "NumberOfInstallments":"",
        "ApplyTaxOnFirstInstallment":"",
        "VatDate":"",
        "DocumentsOwner":"",
        "FolioPrefixString":"",
        "FolioNumber":"",
        "DocumentSubType":"",
        "BPChannelCode":"",
        "BPChannelContact":"",
        "Address2":"",
        "PayToCode":"",
        "ManualNumber":"",
        "UseShpdGoodsAct":"",
        "IsPayToBank":"",
        "PayToBankCountry":"",
        "PayToBankCode":"",
        "PayToBankAccountNo":"",
        "PayToBankBranch":"",
        "BPL_IDAssignedToInvoice":"",
        "DownPayment":"",
        "ReserveInvoice":"",
        "LanguageCode":"",
        "TrackingNumber":"",
        "PickRemark":"",
        "ClosingDate":"",
        "SequenceCode":"",
        "SequenceSerial":"",
        "SeriesString":"",
        "SubSeriesString":"",
        "SequenceModel":"",
        "UseCorrectionVATGroup":"",
        "DownPaymentAmount":"",
        "DownPaymentPercentage":"",
        "DownPaymentType":"",
        "DownPaymentAmountSC":"",
        "DownPaymentAmountFC":"",
        "VatPercent":"",
        "ServiceGrossProfitPercent":"",
        "OpeningRemarks":"",
        "ClosingRemarks":"",
        "RoundingDiffAmount":"",
        "ControlAccount":"",
        "InsuranceOperation347":"",
        "ArchiveNonremovableSalesQuotation":"",
        "GTSChecker":"",
        "GTSPayee":"",
        "ExtraMonth":"",
        "ExtraDays":"",
        "CashDiscountDateOffset":"",
        "StartFrom":"",
        "NTSApproved":"",
        "ETaxWebSite":"",
        "ETaxNumber":"",
        "NTSApprovedNumber":"",
        "EDocGenerationType":"",
        "EDocSeries":"",
        "EDocNum":"",
        "EDocExportFormat":"",
        "EDocStatus":"",
        "EDocErrorCode":"",
        "EDocErrorMessage":"",
        "DownPaymentStatus":"",
        "GroupSeries":"",
        "GroupNumber":"",
        "GroupHandWritten":"",
        "ReopenOriginalDocument":"",
        "ReopenManuallyClosedOrCanceledDocument":"",
        "CreateOnlineQuotation":"",
        "POSEquipmentNumber":"",
        "POSManufacturerSerialNumber":"",
        "POSCashierNumber":"",
        "ApplyCurrentVATRatesForDownPaymentsToDraw":"",
        "ClosingOption":"",
        "SpecifiedClosingDate":"",
        "OpenForLandedCosts":"",
        "RelevantToGTS":"",
        "AnnualInvoiceDeclarationReference":"",
        "Supplier":"",
        "Releaser":"",
        "Receiver":"",
        "BlanketAgreementNumber":"",
        "IsAlteration":"",
        "AssetValueDate":"",
        "DocumentDelivery":"",
        "AuthorizationCode":"",
        "StartDeliveryDate":"",
        "StartDeliveryTime":"",
        "EndDeliveryDate":"",
        "EndDeliveryTime":"",
        "VehiclePlate":"",
        "ATDocumentType":"",
        "ElecCommStatus":"",
        "ReuseDocumentNum":"",
        "ReuseNotaFiscalNum":"",
        "PrintSEPADirect":"",
        "FiscalDocNum":"",
        "POSDailySummaryNo":"",
        "POSReceiptNo":"",
        "PointOfIssueCode":"",
        "Letter":"",
        "FolioNumberFrom":"",
        "FolioNumberTo":"",
        "InterimType":"",
        "RelatedType":"",
        "RelatedEntry":"",
        "DocumentTaxID":"",
        "DateOfReportingControlStatementVAT":"",
        "ReportingSectionControlStatementVAT":"",
        "ExcludeFromTaxReportControlStatementVAT":"",
        "POS_CashRegister":"",
        "PriceMode":"",
        "ShipFrom":"",
        "CommissionTrade":"",
        "CommissionTradeReturn":"",
        "UseBillToAddrToDetermineTax":"",
        "U_Tipo": "PO",
        "U_Mittente": codemitt,
        "U_NomeMitt": mittente,
        "GroupKey": group_key
    }

def build_por1_row(docNum, lineNum, row, cdc_val, item_code, partnum, group_key, motivo=None):
    por1_row = {
        "ParentKey": docNum,
        "LineNum": lineNum,
        "ItemCode": item_code,
        "ItemDescription":"",
        "Quantity": row.Qta,
        "ShipDate":"",
        "Price": 0,
        "PriceAfterVAT":"",
        "Currency":"",
        "Rate":"",
        "DiscountPercent":"",
        "VendorNum":"",
        "SerialNum":"",
        "WarehouseCode": "CE14-INC",
        "SalesPersonCode":"",
        "CommisionPercent":"",
        "TreeType":"",
        "AccountCode":"",
        "UseBaseUnits":"",
        "SupplierCatNum": row.CodiceMateriale,
        "CostingCode":"",
        "ProjectCode":"NTD",
        "BarCode":"",
        "VatGroup":"",
        "Height1":"",
        "Hight1Unit":"",
        "Height2":"",
        "Height2Unit":"",
        "Lengh1":"",
        "Lengh1Unit":"",
        "Lengh2":"",
        "Lengh2Unit":"",
        "Weight1":"",
        "Weight1Unit":"",
        "Weight2":"",
        "Weight2Unit":"",
        "Factor1":"",
        "Factor2":"",
        "Factor3":"",
        "Factor4":"",
        "BaseType":"",
        "BaseEntry":"",
        "BaseLine":"",
        "Volume":"",
        "VolumeUnit":"",
        "Width1":"",
        "Width1Unit":"",
        "Width2":"",
        "Width2Unit":"",
        "Address":"",
        "TaxCode":"",
        "TaxType":"",
        "TaxLiable":"",
        "BackOrder":"",
        "FreeText":"",
        "ShippingMethod":"",
        "CorrectionInvoiceItem":"",
        "CorrInvAmountToStock":"",
        "CorrInvAmountToDiffAcct":"",
        "WTLiable":"",
        "DeferredTax":"",
        "MeasureUnit":"",
        "UnitsOfMeasurment":"",
        "LineTotal":"",
        "TaxPercentagePerRow":"",
        "TaxTotal":"",
        "ConsumerSalesForecast":"",
        "ExciseAmount":"",
        "CountryOrg":"",
        "SWW":"",
        "TransactionType":"",
        "DistributeExpense":"",
        "RowTotalFC":"",
        "CFOPCode":"",
        "CSTCode":"",
        "Usage":"",
        "TaxOnly":"",
        "UnitPrice":"",
        "LineStatus":"",
        "PackageQuantity":"",
        "LineType":"",
        "COGSCostingCode":"",
        "COGSAccountCode":"",
        "ChangeAssemlyBoMWarehouse":"",
        "GrossBuyPrice":"",
        "GrossBase":"",
        "GrossProfitTotalBasePrice":"",
        "CostingCode2":"",
        "CostingCode3":"",
        "CostingCode4":"",
        "CostingCode5":"",
        "ItemDetails":"",
        "LocationCode":"",
        "ActualDeliveryDate":"",
        "ExLineNo":"",
        "RequiredDate":"",
        "RequiredQuantity":"",
        "COGSCostingCode2":"",
        "COGSCostingCode3":"",
        "COGSCostingCode4":"",
        "COGSCostingCode5":"",
        "CSTforIPI":"",
        "CSTforPIS":"",
        "CSTforCOFINS":"",
        "CreditOriginCode":"",
        "WithoutInventoryMovement":"",
        "AgreementNo":"",
        "AgreementRowNumber":"",
        "ActualBaseEntry":"",
        "ActualBaseLine":"",
        "DocEntry":"",
        "Surpluses":"",
        "DefectAndBreakup":"",
        "Shortages":"",
        "ConsiderQuantity":"",
        "PartialRetirement":"",
        "RetirementQuantity":"",
        "RetirementAPC":"",
        "ThirdParty":"",
        "ExpenseType":"",
        "ReceiptNumber":"",
        "ExpenseOperationType":"",
        "FederalTaxID":"",
        "UoMEntry":"",
        "InventoryQuantity":"",
        "ParentLineNum":"",
        "Incoterms":"",
        "TransportMode":"",
        "ChangeInventoryQuantityIndependently":"",
        "FreeOfChargeBP":"",
        "SACEntry":"",
        "HSNEntry":"",
        "GrossPrice":"",
        "GrossTotal":"",
        "GrossTotalFC":"",
        "NCMCode":"",
        "ShipFromCode":"",
        "ShipFromDescription":"",
        "U_PartNumber": partnum,
        "U_PO": row.NumPO,
        "U_CDC": cdc_val,
        "U_Posizione": r.PosPO,
        "GroupKey": group_key
    }
    
    # Aggiungi la colonna Motivo_Errore solo se specificato
    if motivo is not None:
        por1_row["Motivo_Errore"] = motivo
        
    return por1_row

# Aggiungi chiave di raggruppamento
df["group_key"] = df.apply(lambda r: f"{r['NumPO']}_{r['PrevCons'] if r['PrevCons'] else r['PODeliveryDate']}", axis=1)

# Qui accumuliamo righe nuove da inserire nello storico per fare un unico append alla fine (come il save del workbook)
nuove_righe_storico = []

for group_key, group in df.groupby("group_key", sort=False):
    first_row = group.iloc[0]
    mittente = get_mittente(first_row["NomeFornitore"])
    codemitt = get_codemitt(first_row["NomeFornitore"])

    has_undefined = any(
        get_itemcode(r.CodiceMateriale) == "DA DEFINIRE" or mittente == "NON DEFINITO"
        for r in group.itertuples(index=False)
    )

    opor_row = build_opor_row(group_key, first_row, mittente, codemitt)
    por1_temp, da_def_temp = [], []
    lineNum = max_linenum_dict.get(first_row["NumPO"], -1) + 1

    for r in group.itertuples(index=False):
        quintupla = (r.NumPO, r.DataPO, str(r.Qta), r.CodiceMateriale, group_key)
        if quintupla in storico_records:
            continue

        item_code = get_itemcode(r.CodiceMateriale)
        partnum = get_partnumber(r.CodiceMateriale)
        cdc_val = get_cdc(r.Plant)

        try:
            lineNum_excel = int(r.PosPO)
        except:
            lineNum += 1 # fallback in caso di errore
            lineNum_excel = lineNum  # fallback in caso di errore

        # Determina il motivo del "DA DEFINIRE" se necessario
        motivo = []
        if item_code == "DA DEFINIRE":
            motivo.append(f"Materiale non trovato: {r.CodiceMateriale}")
        if mittente == "NON DEFINITO":
            motivo.append(f"Mittente non definito: {r.NomeFornitore}")
        motivo = ", ".join(motivo) if motivo else None

        por1_row = build_por1_row(docNum, lineNum_excel, r, cdc_val, item_code, partnum, group_key, motivo)

        if has_undefined:
            # Per il file Da Definire, includi tutti i campi di OPOR + POR1 + Motivo_Errore
            riga_completa = {**opor_row, **por1_row}
            da_def_temp.append(riga_completa)
        else:
            por1_temp.append(por1_row)
            oggi = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            # Accumula da scrivere nello storico (alla fine verrà fatto un to_sql append)
            nuove_righe_storico.append({
                "NumPO": r.NumPO,
                "DataPO": r.DataPO,
                "Qta": r.Qta,
                "CodiceMateriale": r.CodiceMateriale,
                "MaxLineNum": por1_row["LineNum"],
                "DataCaricamento": oggi,
                "group_key": group_key
            })
            max_linenum_dict[r.NumPO] = por1_row["LineNum"]

    if not has_undefined and por1_temp:
        opor_list.append(opor_row)
        por1_list.extend(por1_temp)
        docNum += 1
    else:
        da_definire_list.extend(da_def_temp)

# ========================
# 7. Scrittura output
# ========================
def write_csv_with_second_header(df_list, filepath, second_header, is_da_definire=False):
    """Scrive CSV con due righe di intestazione e forza tutti i valori come testo."""
    df = pd.DataFrame(df_list)
    
    # ✅ Forza tutti i valori in stringa per evitare problemi in Excel
    df = df.astype(str)

    # Se non è il file Da_Definire, rimuovi le colonne non volute
    if not is_da_definire:
        for col in ['GroupKey', 'Motivo_Errore']:
            if col in df.columns:
                df = df.drop(columns=[col])
    else:
        # Per il file Da_Definire, rimuovi le colonne completamente vuote
        df = df.dropna(axis=1, how='all')
    
    with open(filepath, "w", encoding="utf-8-sig", newline="") as f:
        # prima riga: intestazioni classiche
        f.write(",".join(df.columns) + "\n")
        # seconda riga: intestazioni SAP
        f.write(",".join(second_header[:len(df.columns)]) + "\n")
        # poi i dati veri e propri
        df.to_csv(f, index=False, header=False, sep=",", mode='a')

# intestazioni SAP (seconda riga)
opor_second_header = [
    "DocNum","DocEntry","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode",
    "CardName","Address","NumAtCard","DocTotal","AtcEntry","DocCur","DocRate","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt",
    "SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply","ObjType","ShipToCode",
    "Indicator","LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099",
    "RevisionPo","ReqDate","CancelDate","BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef",
    "CntrlBnk","MaxDscn","Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref",
    "FolioNum","DocSubType","BPChCode","BPChCntc","Address2","PayToCode","ManualNum","UseShpdGd",
    "IsPaytoBnk","BnkCntry","BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns",
    "LangCode","TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model",
    "UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC","VatPercent","SrvGpPrcnt",
    "Header","Footer","RoundDif","CtlAccount","InsurOp347","IgnRelDoc","Checker","Payee",
    "ExtraMonth","ExtraDays","CdcOffset","PayDuMonth","NTSApprov","NTSWebSite","NTSeTaxNo",
    "NTSApprNo","EDocGenTyp","ESeries","EDocExpFrm","EDocStatus","EDocErrCod","EDocErrMsg",
    "DpmStatus","PQTGrpSer","PQTGrpNum","PQTGrpHW","ReopOriDoc","ReopManCls","OnlineQuo",
    "POSEqNum","POSManufSN","POSCashN","DpmAsDscnt","ClosingOpt","SpecDate","OpenForLaC",
    "GTSRlvnt","AnnInvDecR","Supplier","Releaser","Receiver","AgrNo","IsAlt","AssetDate",
    "DocDlvry","AuthCode","StDlvDate","StDlvTime","EndDlvDate","EndDlvTime","VclPlate","AtDocType",
    "ElCoStatus","ElCoMsg","IsReuseNum","IsReuseNFN","PrintSEPA","FiscDocNum","ZrdAbs","POSRcptNo",
    "PTICode","Letter","FolNumFrom","FolNumTo","InterimTyp","RelatedTyp","RelatedEnt","DocTaxID",
    "DateReport","RepSection","ExclTaxRep","PosCashReg","PriceMode","ShipToCode","ComTrade",
    "ComTradeRt","UseBilAddr","U_Tipo","U_Mittente","U_NomeMitt"
]

por1_second_header = [
    "DocNum","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT",
    "Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SubCatNum","OcrCode","Project","CodeBars","VatGroup",
    "Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4",
    "BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag",
    "ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","TotalFrgn",
    "CFOPCode","CSTCode","Usage","TaxOnly","PriceBefDi","LineStatus","PackQty","LineType",
    "CogsOcrCod","CogsAcct","ChgAsmBoMW","GrossBuyPr","GrossBase","GPTtlBasPr","OcrCode2",
    "OcrCode3","OcrCode4","OcrCode5","Text","LocCode","ActDelDate","ExLineNo","PQTReqDate",
    "PQTReqQty","CogsOcrCo2","CogsOcrCo3","CogsOcrCo4","CogsOcrCo5","CSTfIPI","CSTfPIS",
    "CSTfCOFINS","CredOrigin","NoInvtryMv","AgrNo","AgrLnNum","ActBaseEnt","ActBaseLn",
    "DocEntry","Surpluses","DefBreak","Shortages","NeedQty","PartRetire","RetireQty","RetireAPC",
    "ThirdParty","ExpType","ExpUUID","ExpOpType","LicTradNum","UomEntry","InvQty","PrntLnNum",
    "Incoterms","TransMod","InvQtyOnly","FreeChrgBP","SacEntry","HsnEntry","GPBefDisc","GTotal",
    "GTotalFC","NCMCode","ShipFromCo","ShipFromDe","U_PartNumber","U_PO","U_CDC","U_Posizione"
]

# Scrivi i file
if opor_list:
    write_csv_with_second_header(opor_list, opor_out, opor_second_header)
    logging.info(f"File OPOR generato: {opor_out}")

if por1_list:
    write_csv_with_second_header(por1_list, por1_out, por1_second_header)
    logging.info(f"File POR1 generato: {por1_out}")

if da_definire_list:
    # Aggiungi "Motivo_Errore" all'header per il file Da_Definire
    write_csv_with_second_header(da_definire_list, da_definire_out, por1_second_header + ["Motivo_Errore"], is_da_definire=True)
    logging.warning(f"File PO_Da_Definire generato: {da_definire_out}")
# ========================
# 7B. Controllo se è stato generato qualcosa
# ========================
if not opor_list and not por1_list and not da_definire_list:
    logging.warning("⚠️ Nessun nuovo ordine da elaborare: tutti i PO erano già presenti nello storico.")
else:
    if opor_list or por1_list:
        logging.info("✅ Template OPOR e POR1 Creati Con Successo.")
    if da_definire_list:
        logging.warning("⚠️ Attenzione: sono state trovate incongruenze, controllare il file PO_Da_Definire.")    
# ===================================================================
# Pulizia file PO_Da_Definire: rimuove colonne vuote e seconda intestazione
# ===================================================================
try:
    if os.path.exists(da_definire_out):
        # Legge tutto come testo per evitare conversioni indesiderate
        df_def = pd.read_csv(da_definire_out, dtype=str, header=None).fillna("")

        # Rimuove semplicemente la seconda riga (che è la seconda intestazione)
        if len(df_def) > 1:
            df_def = df_def.drop(index=1).reset_index(drop=True)
        
        #  Rimuove eventuali spazi o caratteri invisibili
        df_def = df_def.map(lambda x: x.strip() if isinstance(x, str) else x)
       
        # Controlla colonne vuote SOLO sui dati (cioè dalla seconda riga in poi)
        if len(df_def) > 1:
            dati = df_def.iloc[1:]  # dalla seconda riga (dopo intestazione)
            non_empty_cols = dati.columns[(dati.replace("", pd.NA).notna()).any(axis=0)]
            df_def = df_def[non_empty_cols]
            

        # Riscrive il file CSV
        df_def.to_csv(da_definire_out, index=False, header=False, sep=",")
        logging.info(f"⚠️ Attenzione Sono Stati Trovate Delle Incongruenze , File Generato : {da_definire_out}")
        # Invia l'email con il file allegato
        invia_email_smtp(da_definire_out)   
    else:
        logging.info(f"✅ Se Presenti PO Nuovi , I Template OPOR e POR1 Sono Stati Creati Con Successo , Nessuna Incongruenza Trovata!")
except Exception as e:
    logging.error(f"❌ Errore durante la pulizia di PO_Da_Definire: {e}")
      

# ========================
# 8. Salva storico su DB (sostituisce wb.save)
# ========================
try:
    if nuove_righe_storico:
        df_nuove = pd.DataFrame(nuove_righe_storico)
        # Appendi le nuove righe alla tabella StoricoOrdiniCaricati
        df_nuove.to_sql("StoricoOrdiniCaricatiNTD", conn, if_exists="append", index=False)
        conn.commit()
        logging.info("Storico aggiornato con i nuovi PO definiti (DB).")
    else:
        logging.info("Nessuna nuova riga da salvare nello storico.")
except Exception as e:
    logging.error(f"Errore salvando lo storico nel DB: {e}")

# Chiudi connessione DB
try:
    conn.close()
    logging.info("Connessione al database SQLite chiusa con successo.")
except Exception as e:
    logging.warning(f"Errore chiusura DB: {e}")

logging.info("=== END SCRIPT ===")
print("\n✅ Elaborazione completata con successo!")
input("\nPremi INVIO per chiudere...")
