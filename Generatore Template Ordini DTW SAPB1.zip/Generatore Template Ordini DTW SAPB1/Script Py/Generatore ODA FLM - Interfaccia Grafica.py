# Generatore ODA FLM - GUI.py
import os
import sys
import gzip
import shutil
import pandas as pd
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime
from threading import Thread
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import logging

# ========================
# 0. Cartella base
# ========================
if getattr(sys, "frozen", False):
    base_path = os.path.dirname(sys.executable)
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

log_path = os.path.join(base_path, "ODA_FLM_Log.txt")
db_path = os.path.join(base_path, "Database_Generatore.db")
output_folder = os.path.join(base_path, "DTWOrdiniAcquistoOutput_FLM")
os.makedirs(output_folder, exist_ok=True)

# ========================
# Logger GUI + File
# ========================
class GUILogger:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.log_file = open(log_path, "a", encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[logging.StreamHandler(self)])

    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)
        self.log_file.write(message)
        self.log_file.flush()

    def flush(self): pass

# ========================
# GUI
# ========================
root = tk.Tk()
root.title("Generatore ODA FLM - ATS")
root.geometry("820x680")
root.resizable(False, False)
root.configure(bg="#f0f4f8")

style = ttk.Style()
style.theme_use('clam')

tk.Label(root, text="GENERATORE ODA FLM", font=("Segoe UI", 20, "bold"), bg="#f0f4f8", fg="#2c3e50").pack(pady=(25, 8))
tk.Label(root, text="Seleziona il file FR.CSV o FR.CSV.GZ per generare i DTW", font=("Segoe UI", 10), bg="#f0f4f8", fg="#7f8c8d").pack(pady=(0, 20))

frame = tk.Frame(root, bg="#f0f4f8")
frame.pack(pady=10, padx=35, fill="both", expand=True)

btn_scegli = tk.Button(frame, text="SCEGLI FILE FR.CSV / FR.CSV.GZ", font=("Segoe UI", 11, "bold"), width=40, height=2, bg="#3498db", fg="white", relief="flat", cursor="hand2")
btn_scegli.pack(pady=15)

lbl_file = tk.Label(frame, text="Nessun file selezionato", font=("Segoe UI", 10), bg="#f0f4f8", fg="#95a5a6", wraplength=720)
lbl_file.pack(pady=(5, 15))

progress = ttk.Progressbar(frame, mode='determinate', length=720)
progress.pack(pady=10)

log_frame = tk.Frame(frame, bg="white", relief="sunken", bd=1)
log_frame.pack(pady=15, fill="both", expand=True)

log_text = tk.Text(log_frame, height=18, font=("Consolas", 9), bg="#fdfdfd", fg="#2c3e50", wrap="word")
log_text.pack(side="left", fill="both", expand=True, padx=5, pady=5)
scrollbar = tk.Scrollbar(log_frame, command=log_text.yview)
scrollbar.pack(side="right", fill="y")
log_text.config(yscrollcommand=scrollbar.set)

footer = tk.Label(root, text=f"Output: {output_folder} | DB: Database_Generatore.db | Log: ODA_FLM_Log.txt", font=("Segoe UI", 8), bg="#f0f4f8", fg="#95a5a6")
footer.pack(side="bottom", pady=15)

csv_path = None
logger = None

# ========================
# INVIO MAIL
# ========================
def invia_email_smtp(filepath, to="dizzo@atsgruppo.eu"):
    msg = MIMEMultipart()
    msg['From'] = "atssegnalazioni@gmail.com"
    msg['To'] = to
    msg['Subject'] = f"FR Da Definire - {datetime.now():%d/%m/%Y}"
    with open(filepath, "rb") as f:
        part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
        msg.attach(part)
    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("atssegnalazioni@gmail.com", "xxx")
            server.send_message(msg)
        logging.info("Email inviata via Gmail SMTP")
        return True
    except Exception as e:
        logging.error(f"SMTP fallito: {e}")
        return False

# ========================
# COLONNE DTW (COMPLETE)
# ========================
opor_columns = [
    "DocNum","DocEntry","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode",
    "CardName","Address","NumAtCard","DocTotal","AtcEntry","DocCur","DocRate","Ref1","Ref2","Comments",
    "JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt","SummryType",
    "CntctCode","ShowSCN","Series","TaxDate","PartSupply","ObjType","ShipToCode","Indicator",
    "LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate",
    "CancelDate","BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn",
    "Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv","DeferrTax","LetterNum",
    "AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref","FolioNum","DocSubType",
    "BPChCode","BPChCntc","Address2","PayToCode","ManualNum","UseShpdGd","IsPaytoBnk","BnkCntry",
    "BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode","TrackNo","PickRmrk",
    "ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model","UseCorrVat","DpmAmnt","DpmPrcnt",
    "Posted","DpmAmntSC","DpmAmntFC","VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount",
    "InsurOp347","IgnRelDoc","Checker","Payee","ExtraMonth","ExtraDays","CdcOffset","PayDuMonth",
    "NTSApprov","NTSWebSite","NTSeTaxNo","NTSApprNo","EDocGenTyp","ESeries","EDocExpFrm","EDocStatus",
    "EDocErrCod","EDocErrMsg","DpmStatus","PQTGrpSer","PQTGrpNum","PQTGrpHW","ReopOriDoc","ReopManCls",
    "OnlineQuo","POSEqNum","POSManufSN","POSCashN","DpmAsDscnt","ClosingOpt","SpecDate","OpenForLaC",
    "GTSRlvnt","AnnInvDecR","Supplier","Releaser","Receiver","AgrNo","IsAlt","AssetDate","DocDlvry",
    "AuthCode","StDlvDate","StDlvTime","EndDlvDate","EndDlvTime","VclPlate","AtDocType","ElCoStatus",
    "ElCoMsg","IsReuseNum","IsReuseNFN","PrintSEPA","FiscDocNum","ZrdAbs","POSRcptNo","PTICode",
    "Letter","FolNumFrom","FolNumTo","InterimTyp","RelatedTyp","RelatedEnt","DocTaxID","DateReport",
    "RepSection","ExclTaxRep","PosCashReg","PriceMode","ShipToCode","ComTrade","ComTradeRt","UseBilAddr",
    "U_Tipo","U_Mittente","U_NomeMitt","U_Riparatore"
]

por1_columns = [
    "DocNum","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT",
    "Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SubCatNum","OcrCode","Project","CodeBars","VatGroup",
    "Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4",
    "BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2",
    "Wdth2Unit","Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode",
    "CEECFlag","ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal",
    "VatPrcnt","VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp",
    "TotalFrgn","CFOPCode","CSTCode","Usage","TaxOnly","PriceBefDi","LineStatus","PackQty",
    "LineType","CogsOcrCod","CogsAcct","ChgAsmBoMW","GrossBuyPr","GrossBase","GPTtlBasPr",
    "OcrCode2","OcrCode3","OcrCode4","OcrCode5","Text","LocCode","ActDelDate","ExLineNo",
    "PQTReqDate","PQTReqQty","CogsOcrCo2","CogsOcrCo3","CogsOcrCo4","CogsOcrCo5","CSTfIPI",
    "CSTfPIS","CSTfCOFINS","CredOrigin","NoInvtryMv","AgrNo","AgrLnNum","ActBaseEnt","ActBaseLn",
    "DocEntry","Surpluses","DefBreak","Shortages","NeedQty","PartRetire","RetireQty","RetireAPC",
    "ThirdParty","ExpType","ExpUUID","ExpOpType","LicTradNum","UomEntry","InvQty","PrntLnNum",
    "Incoterms","TransMod","InvQtyOnly","FreeChrgBP","SacEntry","HsnEntry","GPBefDisc","GTotal",
    "GTotalFC","NCMCode","ShipFromCo","ShipFromDe","U_PartNumber","U_PO","U_CDC","U_Seriale"
]

opor_header_sap = [
    "DocNum","DocEntry","DocType","HandWritten","Printed","DocDate","DocDueDate","CardCode",
    "CardName","Address","NumAtCard","DocTotal","AttachmentEntry","DocCurrency","DocRate",
    "Reference1","Reference2","Comments","JournalMemo","PaymentGroupCode","DocTime",
    "SalesPersonCode","TransportationCode","Confirmed","ImportFileNum","SummeryType",
    "ContactPersonCode","ShowSCN","Series","TaxDate","PartialSupply","DocObjectCode",
    "ShipToCode","Indicator","FederalTaxID","DiscountPercent","PaymentReference","DocTotalFc",
    "Form1099","Box1099","RevisionPo","RequriedDate","CancelDate","BlockDunning","Pick",
    "PaymentMethod","PaymentBlock","PaymentBlockEntry","CentralBankIndicator",
    "MaximumCashDiscount","Project","ExemptionValidityDateFrom","ExemptionValidityDateTo",
    "WareHouseUpdateType","Rounding","ExternalCorrectedDocNum","InternalCorrectedDocNum",
    "DeferredTax","TaxExemptionLetterNum","AgentCode","NumberOfInstallments",
    "ApplyTaxOnFirstInstallment","VatDate","DocumentsOwner","FolioPrefixString","FolioNumber",
    "DocumentSubType","BPChannelCode","BPChannelContact","Address2","PayToCode","ManualNumber",
    "UseShpdGoodsAct","IsPayToBank","PayToBankCountry","PayToBankCode","PayToBankAccountNo",
    "PayToBankBranch","BPL_IDAssignedToInvoice","DownPayment","ReserveInvoice","LanguageCode",
    "TrackingNumber","PickRemark","ClosingDate","SequenceCode","SequenceSerial","SeriesString",
    "SubSeriesString","SequenceModel","UseCorrectionVATGroup","DownPaymentAmount",
    "DownPaymentPercentage","DownPaymentType","DownPaymentAmountSC","DownPaymentAmountFC",
    "VatPercent","ServiceGrossProfitPercent","OpeningRemarks","ClosingRemarks",
    "RoundingDiffAmount","ControlAccount","InsuranceOperation347","ArchiveNonremovableSalesQuotation",
    "GTSChecker","GTSPayee","ExtraMonth","ExtraDays","CashDiscountDateOffset","StartFrom",
    "NTSApproved","ETaxWebSite","ETaxNumber","NTSApprovedNumber","EDocGenerationType",
    "EDocSeries","EDocNum","EDocExportFormat","EDocStatus","EDocErrorCode","EDocErrorMessage",
    "DownPaymentStatus","GroupSeries","GroupNumber","GroupHandWritten","ReopenOriginalDocument",
    "ReopenManuallyClosedOrCanceledDocument","CreateOnlineQuotation","POSEquipmentNumber",
    "POSManufacturerSerialNumber","POSCashierNumber","ApplyCurrentVATRatesForDownPaymentsToDraw",
    "ClosingOption","SpecifiedClosingDate","OpenForLandedCosts","RelevantToGTS",
    "AnnualInvoiceDeclarationReference","Supplier","Releaser","Receiver",
    "BlanketAgreementNumber","IsAlteration","AssetValueDate","DocumentDelivery",
    "AuthorizationCode","StartDeliveryDate","StartDeliveryTime","EndDeliveryDate",
    "EndDeliveryTime","VehiclePlate","ATDocumentType","ElecCommStatus","ReuseDocumentNum",
    "ReuseNotaFiscalNum","PrintSEPADirect","FiscalDocNum","POSDailySummaryNo","POSReceiptNo",
    "PointOfIssueCode","Letter","FolioNumberFrom","FolioNumberTo","InterimType","RelatedType",
    "RelatedEntry","DocumentTaxID","DateOfReportingControlStatementVAT",
    "ReportingSectionControlStatementVAT","ExcludeFromTaxReportControlStatementVAT",
    "POS_CashRegister","PriceMode","ShipFrom","CommissionTrade","CommissionTradeReturn",
    "UseBillToAddrToDetermineTax","U_Tipo","U_Mittente","U_NomeMitt"
]

por1_header_sap = [
    "ParentKey","LineNum","ItemCode","ItemDescription","Quantity","ShipDate","Price",
    "PriceAfterVAT","Currency","Rate","DiscountPercent","VendorNum","SerialNum",
    "WarehouseCode","SalesPersonCode","CommisionPercent","TreeType","AccountCode",
    "UseBaseUnits","SupplierCatNum","CostingCode","ProjectCode","BarCode","VatGroup",
    "Height1","Hight1Unit","Height2","Height2Unit","Lengh1","Lengh1Unit","Lengh2",
    "Lengh2Unit","Weight1","Weight1Unit","Weight2","Weight2Unit","Factor1","Factor2",
    "Factor3","Factor4","BaseType","BaseEntry","BaseLine","Volume","VolumeUnit",
    "Width1","Width1Unit","Width2","Width2Unit","Address","TaxCode","TaxType","TaxLiable",
    "BackOrder","FreeText","ShippingMethod","CorrectionInvoiceItem","CorrInvAmountToStock",
    "CorrInvAmountToDiffAcct","WTLiable","DeferredTax","MeasureUnit","UnitsOfMeasurment",
    "LineTotal","TaxPercentagePerRow","TaxTotal","ConsumerSalesForecast","ExciseAmount",
    "CountryOrg","SWW","TransactionType","DistributeExpense","RowTotalFC","CFOPCode",
    "CSTCode","Usage","TaxOnly","UnitPrice","LineStatus","PackageQuantity","LineType",
    "COGSCostingCode","COGSAccountCode","ChangeAssemlyBoMWarehouse","GrossBuyPrice",
    "GrossBase","GrossProfitTotalBasePrice","CostingCode2","CostingCode3","CostingCode4",
    "CostingCode5","ItemDetails","LocationCode","ActualDeliveryDate","ExLineNo",
    "RequiredDate","RequiredQuantity","COGSCostingCode2","COGSCostingCode3",
    "COGSCostingCode4","COGSCostingCode5","CSTforIPI","CSTforPIS","CSTforCOFINS",
    "CreditOriginCode","WithoutInventoryMovement","AgreementNo","AgreementRowNumber",
    "ActualBaseEntry","ActualBaseLine","DocEntry","Surpluses","DefectAndBreakup",
    "Shortages","ConsiderQuantity","PartialRetirement","RetirementQuantity","RetirementAPC",
    "ThirdParty","ExpenseType","ReceiptNumber","ExpenseOperationType","FederalTaxID",
    "UoMEntry","InventoryQuantity","ParentLineNum","Incoterms","TransportMode",
    "ChangeInventoryQuantityIndependently","FreeOfChargeBP","SACEntry","HSNEntry",
    "GrossPrice","GrossTotal","GrossTotalFC","NCMCode","ShipFromCode","ShipFromDescription",
    "U_PartNumber","U_PO","U_CDC","U_Seriale"
]

# ========================
# ELABORAZIONE
# ========================
def avvia_elaborazione():
    global csv_path, logger
    if not csv_path:
        messagebox.showerror("Errore", "Seleziona un file!")
        return

    logger = GUILogger(log_text)
    sys.stdout = logger
    log_text.delete(1.0, tk.END)

    def run():
        try:
            progress['value'] = 0
            root.update()

            # Decompressione
            if csv_path.endswith(".gz"):
                decompressed_path = os.path.join(base_path, "fr.csv")
                with gzip.open(csv_path, "rb") as f_in, open(decompressed_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
                csv_path_local = decompressed_path
                print(f"Decompresso in: {csv_path_local}")
            else:
                csv_path_local = csv_path

            print(f"File selezionato: {csv_path_local}")
            progress['value'] = 5
            root.update()

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            opor_out = os.path.join(output_folder, f"OPOR_{timestamp}.csv")
            por1_out = os.path.join(output_folder, f"POR1_{timestamp}.csv")
            da_definire_out = os.path.join(output_folder, f"FR_Da_Definire_{timestamp}.csv")

            #df = pd.read_csv(csv_path_local, sep="|", engine="python", dtype=str, keep_default_na=False, quoting=3)
            df = pd.read_csv(csv_path_local, sep="|", engine="python", dtype=str, keep_default_na=False, quoting=3,on_bad_lines="warn",usecols=range(57))
  
        
            print(f"Totale righe lette: {len(df)}")
            progress['value'] = 10
            root.update()

            df["stato"] = df["stato"].astype(str).str.strip()
            df["data_dt"] = pd.to_datetime(df["data_ultima_modifica"], errors="coerce", dayfirst=True)

            group_main = ["Open", "Failed Material Sent"]
            group_good = ["Failed Material sent to Repairer", "Failed Material sent to Repairer (AS)"]

            df_main = df[df["stato"].isin(group_main) & (df["data_dt"].dt.year >= 2025)].copy()
            df_good = df[df["stato"].isin(group_good) & (df["data_dt"].dt.year >= 2025)].copy()

            print(f"Righe gruppo principale: {len(df_main)}")
            print(f"Righe gruppo 'good': {len(df_good)}")
            progress['value'] = 20
            root.update()

            conn = sqlite3.connect(db_path)

            fr_storico_main = pd.read_sql_query('SELECT FR FROM "StoricoOrdiniCaricatiFLM"', conn)
            fr_storico_good = pd.read_sql_query('SELECT FR FROM "StoricoOrdiniCaricatiGoodFLM"', conn)
            fr_storico_main = fr_storico_main["FR"].astype(str).str.strip().tolist() if not fr_storico_main.empty else []
            fr_storico_good = fr_storico_good["FR"].astype(str).str.strip().tolist() if not fr_storico_good.empty else []

            df_main = df_main[~df_main["fr_id"].astype(str).str.strip().isin(fr_storico_main)]
            df_good = df_good[~df_good["fr_id"].astype(str).str.strip().isin(fr_storico_good)]

            print(f"Righe da elaborare gruppo principale: {len(df_main)}")
            print(f"Righe da elaborare gruppo 'good': {len(df_good)}")
            progress['value'] = 30
            root.update()

            conv_depositi = pd.read_sql_query('SELECT * FROM "Conversione Depositi VLT"', conn).fillna("")
            for c in ["VLT", "nome_dtw", "codice_dtw", "CONVERSIONE_RIPARATORE"]:
                if c not in conv_depositi.columns:
                    conv_depositi[c] = ""

            try:
                anagrafica = pd.read_sql_query('''
                    SELECT * FROM "Anagrafica_SAP" WHERE "Codice articolo (ATS)" LIKE '%-FLM'
                ''', conn).fillna("")
                for c in ["Codice articolo (ATS)", "Material SAP Code (BP)"]:
                    if c not in anagrafica.columns:
                        anagrafica[c] = ""
                if "Material SAP Code (BP)" in anagrafica.columns:
                    anagrafica["Material SAP Code (BP)"] = anagrafica["Material SAP Code (BP)"].astype(str).str.strip()
                logging.info(f"Anagrafica FLM caricata: {len(anagrafica)} righe")
            except Exception as e:
                logging.error(f"Errore lettura Anagrafica_SAP: {e}")
                anagrafica = pd.DataFrame([{"Codice articolo (ATS)": "", "Material SAP Code (BP)": ""}])

            def prepare_df(df_input, use_riparatore=False):
                merge_key = "riparatore" if use_riparatore else "depot_origine"
                df_input[merge_key] = df_input[merge_key].astype(str).str.strip().str.upper()
                conv_depositi["VLT"] = conv_depositi["VLT"].astype(str).str.strip().str.upper()

                df_input = df_input.merge(conv_depositi[["VLT","nome_dtw","codice_dtw"]], how="left", left_on=merge_key, right_on="VLT")
                df_input["U_Mittente_Orig"] = df_input[merge_key].astype(str).str.strip()
                df_input["ItemCode_Orig"] = df_input["f_mat_material"].astype(str).str.strip()

                df_input["U_NomeMitt"] = df_input["nome_dtw"].fillna("").astype(str).str.strip()
                df_input["U_Mittente"] = df_input["codice_dtw"].fillna("").astype(str).str.strip()
                df_input.loc[df_input["U_Mittente"].astype(str).str.strip() == "", "U_Mittente"] = "NON DEFINITO"
                df_input.loc[df_input["U_Mittente"].astype(str).str.upper() == "0", "U_Mittente"] = "NON DEFINITO"
                df_input.loc[df_input["U_NomeMitt"].astype(str).str.strip() == "", "U_NomeMitt"] = "NON DEFINITO"

                df_input = df_input.drop(columns=["VLT","nome_dtw","codice_dtw"], errors="ignore")

                df_input["riparatore"] = df_input["riparatore"].astype(str).str.strip().str.upper()
                conv_depositi["CONVERSIONE_RIPARATORE"] = conv_depositi["CONVERSIONE_RIPARATORE"].astype(str).str.strip().str.upper()
                mappa_riparatore = dict(zip(conv_depositi["CONVERSIONE_RIPARATORE"], conv_depositi["codice_dtw"]))
                df_input["U_Riparatore"] = df_input["riparatore"].map(mappa_riparatore).fillna("NON DEFINITO")

                df_input = df_input.merge(anagrafica[["Codice articolo (ATS)","Material SAP Code (BP)"]], how="left", left_on="f_mat_material", right_on="Material SAP Code (BP)")
                df_input["ItemCode"] = df_input["Codice articolo (ATS)"].fillna("DA DEFINIRE")
                df_input = df_input.drop(columns=["Codice articolo (ATS)","Material SAP Code (BP)"], errors="ignore")

                df_input["__item_da_definire_flag"] = df_input["ItemCode"] == "DA DEFINIRE"
                df_input["__mittente_non_trovato_flag"] = df_input["U_Mittente"].astype(str).str.upper() == "NON DEFINITO"

                mitt_missing = df_input["__mittente_non_trovato_flag"].sum()
                item_missing = df_input["__item_da_definire_flag"].sum()
                print(f"{mitt_missing} record con mittente NON DEFINITO, {item_missing} con ItemCode DA DEFINIRE")

                df_input.loc[df_input["U_Riparatore"].astype(str).str.strip() == "", "U_Riparatore"] = "NON DEFINITO"
                return df_input

            df_main = prepare_df(df_main, use_riparatore=False)
            df_good = prepare_df(df_good, use_riparatore=True)
            progress['value'] = 50
            root.update()

            def process_df(df_input, start_docnum, storico_table, tipo):
                opor_list, por1_list, da_definire_list = [], [], []
                docNum = start_docnum
                total_rows = len(df_input)
                print(f"Avvio elaborazione {total_rows} righe...")

                for col in df_input.select_dtypes(include="object").columns:
                    df_input[col] = df_input[col].astype(str).str.strip().str.upper()
                df_input = df_input.drop_duplicates(subset=df_input.columns)

                storico_fr_set = set(pd.read_sql_query(f'SELECT FR FROM {storico_table}', conn)["FR"].astype(str).str.strip().str.upper())

                for idx, row in enumerate(df_input.itertuples(index=False), 1):
                    docDue = getattr(row, "data_dt").strftime("%Y%m%d") if getattr(row, "data_dt") else ""
                    fr_id = getattr(row, "fr_id")
                    fr_id_str = str(fr_id).strip().upper()
                    item_code = getattr(row, "ItemCode")
                    mittente = getattr(row, "U_Mittente", "NON DEFINITO")

                    opor_row = {col: "" for col in opor_columns}
                    opor_row.update({
                        "DocNum": docNum, "DocType": "dDocument_Items", "DocDate": datetime.today().strftime("%Y%m%d"),
                        "DocDueDate": docDue, "CardCode": "F000263", "NumAtCard": fr_id, "Series": 237,
                        "TaxDate": docDue, "Project": "FLM", "U_Tipo": "FR", "U_Mittente": mittente,
                        "U_NomeMitt": getattr(row, "U_NomeMitt", "NON DEFINITO"),
                        "Comments": "Faulty" if tipo == "main" else "Good",
                        "U_Riparatore": getattr(row, "U_Riparatore", "NON DEFINITO")
                    })

                    por1_row = {col: "" for col in por1_columns}
                    por1_row.update({
                        "DocNum": docNum, "LineNum": 0, "ItemCode": item_code, "Quantity": 1,
                        "WhsCode": "CE71-INC", "SubCatNum": getattr(row, "f_mat_material", ""),
                        "Project": "FLM", "U_PartNumber": getattr(row, "f_mat_tmpn", ""),
                        "U_PO": fr_id, "U_CDC": 1, "Price": 0,
                        "U_Seriale": str(getattr(row, "f_mat_serial_no", "")).strip().upper()
                    })

                    error_msgs = []
                    if item_code.upper() == "DA DEFINIRE":
                        orig_item = getattr(row, "ItemCode_Orig", "").strip() or "???"
                        error_msgs.append(f"ItemCode {orig_item} DA DEFINIRE")
                    if mittente.upper() == "NON DEFINITO":
                        orig_mitt = getattr(row, "U_Mittente_Orig", "").strip() or "???"
                        error_msgs.append(f"Mittente {orig_mitt} NON DEFINITO")

                    if error_msgs:
                        da_definire_row = {**opor_row, **por1_row}
                        da_definire_row["Errore1"] = error_msgs[0]
                        da_definire_row["Errore2"] = error_msgs[1] if len(error_msgs) > 1 else ""
                        da_definire_list.append(da_definire_row)
                    else:
                        opor_list.append(opor_row)
                        por1_list.append(por1_row)
                        if fr_id_str not in storico_fr_set:
                            timestamp_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            conn.execute(f'INSERT INTO {storico_table} (FR, TimeStamp) VALUES (?, ?)', (fr_id_str, timestamp_now))
                            conn.commit()
                            storico_fr_set.add(fr_id_str)
                            print(f"FR {fr_id_str} inserito nello storico alle {timestamp_now}")

                    percent = int((idx / total_rows) * 100)
                    bar = "#" * (percent // 2) + "-" * (50 - percent // 2)
                    print(f"\r[{bar}] {percent}% ({idx}/{total_rows})", end="", flush=True)
                    docNum += 1

                print("\nElaborazione completata.")
                return opor_list, por1_list, da_definire_list

            opor_main, por1_main, da_definire_main = process_df(df_main, 1001, '"StoricoOrdiniCaricatiFLM"', "main")
            opor_good, por1_good, da_definire_good = process_df(df_good, 3001, '"StoricoOrdiniCaricatiGoodFLM"', "good")
            progress['value'] = 80
            root.update()

            da_definire_total = da_definire_main + da_definire_good

            df_opor = pd.DataFrame(opor_main + opor_good, columns=opor_columns)
            with open(opor_out, "w", encoding="utf-8", newline="") as f:
                f.write(",".join(opor_header_sap) + "\n")
                f.write(",".join(opor_columns) + "\n")
                df_opor.to_csv(f, index=False, header=False)

            df_por1 = pd.DataFrame(por1_main + por1_good, columns=por1_columns)
            with open(por1_out, "w", encoding="utf-8", newline="") as f:
                f.write(",".join(por1_header_sap) + "\n")
                f.write(",".join(por1_columns) + "\n")
                df_por1.to_csv(f, index=False, header=False)

            if da_definire_total:
                df_da_definire = pd.DataFrame(da_definire_total)
                if "Errore" not in df_da_definire.columns:
                    df_da_definire["Errore"] = ""
                df_da_definire.replace("", pd.NA, inplace=True)
                df_da_definire = df_da_definire.dropna(axis=1, how='all')
                df_da_definire.to_csv(da_definire_out, index=False, sep=",", encoding="utf-8-sig")
                print(f"File FR_Da_Definire generato: {da_definire_out}")
                invia_email_smtp(da_definire_out)

            print(f"File DTW generati:\n- {opor_out}\n- {por1_out}")
            conn.commit()
            conn.close()

            progress['value'] = 100
            messagebox.showinfo("Completato", f"Elaborazione terminata!\nFile in:\n{output_folder}")

        except Exception as e:
            messagebox.showerror("Errore", f"{e}")
        finally:
            if 'conn' in locals():
                conn.close()

    Thread(target=run, daemon=True).start()

def scegli_file():
    global csv_path
    file = filedialog.askopenfilename(
        title="Seleziona il file FR.CSV o FR.CSV.GZ",
        filetypes=[("File CSV", "*.csv"), ("File compressi", "*.csv.gz"), ("Tutti i file", "*.*")]
    )
    if file:
        csv_path = file
        lbl_file.config(text=f"File: {os.path.basename(file)}", fg="#27ae60")
        btn_scegli.config(text="AVVIA ELABORAZIONE", command=avvia_elaborazione, bg="#27ae60")

btn_scegli.config(command=scegli_file)
root.mainloop()