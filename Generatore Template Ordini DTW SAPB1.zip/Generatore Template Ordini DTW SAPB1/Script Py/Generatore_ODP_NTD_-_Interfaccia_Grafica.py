# Generatore ODP NTD - GUI.py
import os
import sys
import gzip
import shutil
import pandas as pd
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk , simpledialog
from datetime import datetime
from threading import Thread
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import logging
import re
from datetime import datetime
import json
import csv
# ========================
# 0. Cartella base
# ========================
if getattr(sys, "frozen", False):
    base_path = os.path.dirname(sys.executable)
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

log_path = os.path.join(base_path, "ODP_NTD_Log.log")
db_path = os.path.join(base_path, "Database_Generatore.db")
output_folder = os.path.join(base_path, "DTWOrdiniVenditaOutputNTD")
os.makedirs(output_folder, exist_ok=True)

#===================================================================================================
#IMPOSTAZIONE CONFIGURAZIONE VALORI HARDCODED
#==================================================================================================    
CONFIG_FILE = "ConfigOdpNtd.json"

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "ordr_defaults": {},
            "rdr1_defaults": {},
            "warehouse_by_cdc": {},
            "warehouse_default": ""
        }

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

def show_config_editor():
    config = load_config()

    root = tk.Toplevel()  # usa Toplevel così non blocchi la finestra principale
    root.title("Editor Configurazione")

    entries = {}

    # Sezione ORDR Defaults
    tk.Label(root, text="Impostazioni ORDR Defaults", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, columnspan=2, pady=(10,5), sticky="w")

    row = 1
    for key, val in config.get("ordr_defaults", {}).items():
        tk.Label(root, text=key).grid(row=row, column=0, sticky="w", padx=5, pady=2)
        entry = tk.Entry(root, width=30)
        entry.grid(row=row, column=1, padx=5, pady=2)
        entry.insert(0, str(val))
        entries[f"ordr_{key}"] = entry  # Prefisso per distinguere
        row += 1

    # Sezione RDR1 Defaults
    tk.Label(root, text="Impostazioni RDR1 Defaults", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=2, pady=(15,5), sticky="w")
    row += 1
    for key, val in config.get("rdr1_defaults", {}).items():
        tk.Label(root, text=key).grid(row=row, column=0, sticky="w", padx=5, pady=2)
        entry = tk.Entry(root, width=30)
        entry.grid(row=row, column=1, padx=5, pady=2)
        entry.insert(0, str(val))
        entries[f"rdr1_{key}"] = entry  # Prefisso per distinguere
        row += 1
    # ================================
    # Sezione Warehouse per CDC
    # ================================
    tk.Label(root, text="Magazzini per CDC", font=("Segoe UI", 10, "bold")).grid(
       row=row, column=0, columnspan=2, pady=(15, 5), sticky="w"
    )
    row += 1

    warehouse_entries = []

    warehouse_by_cdc = config.get("warehouse_by_cdc", {})

    for whs, cdc_list in warehouse_by_cdc.items():
        tk.Label(root, text="Warehouse").grid(row=row, column=0, sticky="w", padx=5)
        whs_entry = tk.Entry(root, width=30)
        whs_entry.grid(row=row, column=1, padx=5)
        whs_entry.insert(0, whs)

        row += 1
        tk.Label(root, text="CDC (separati da ,)").grid(row=row, column=0, sticky="w", padx=5)
        cdc_entry = tk.Entry(root, width=30)
        cdc_entry.grid(row=row, column=1, padx=5)
        cdc_entry.insert(0, ",".join(cdc_list))

        warehouse_entries.append((whs_entry, cdc_entry))
        row += 1

    tk.Label(root, text="Warehouse di default").grid(row=row, column=0, sticky="w", padx=5)
    warehouse_default_entry = tk.Entry(root, width=30)
    warehouse_default_entry.grid(row=row, column=1, padx=5)
    warehouse_default_entry.insert(0, config.get("warehouse_default", ""))
    row += 1    

    def save_and_close():
        for key, entry in entries.items():
            value = entry.get()
            if key.startswith("ordr_"):
                real_key = key[len("ordr_"):]
                config["ordr_defaults"][real_key] = value
            elif key.startswith("rdr1_"):
                real_key = key[len("rdr1_"):]
                config["rdr1_defaults"][real_key] = value
    # --- Warehouse per CDC ---
        new_whs_by_cdc = {}
        for whs_entry, cdc_entry in warehouse_entries:
            whs = whs_entry.get().strip()
            cdc_list = [x.strip() for x in cdc_entry.get().split(",") if x.strip()]
            if whs and cdc_list:
               new_whs_by_cdc[whs] = cdc_list

        config["warehouse_by_cdc"] = new_whs_by_cdc
        config["warehouse_default"] = warehouse_default_entry.get().strip()        

        save_config(config)
        messagebox.showinfo("Salvato", "Configurazione aggiornata!")
        root.destroy()

    btn_save = tk.Button(root, text="Salva e Chiudi", command=save_and_close)
    btn_save.grid(row=row, column=0, columnspan=2, pady=15)

    root.mainloop()


# ========================
# Logger GUI + File
# ========================
class GUILogger:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.log_file = open(log_path, "a", encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[logging.StreamHandler(self)])

    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)
        self.log_file.write(message)
        self.log_file.flush()

    def flush(self): pass

# ========================
# GUI
# ========================
root = tk.Tk()
root.title("Generatore ODP NTD - ATS")
root.geometry("820x680")
root.resizable(False, False)
root.configure(bg="#f0f4f8")

style = ttk.Style()
style.theme_use('clam')

# Frame in alto per pulsante impostazioni
top_frame = tk.Frame(root, bg="#f0f4f8")
top_frame.pack(side="top", fill="x", padx=10, pady=5)

btn_settings = tk.Button(top_frame, text="⚙️", font=("Segoe UI", 14), bg="#f0f4f8", fg="#2c3e50",
                         relief="flat", cursor="hand2", command=show_config_editor)
btn_settings.pack(side="right")

tk.Label(root, text="GENERATORE ODP NTD", font=("Segoe UI", 20, "bold"), bg="#f0f4f8", fg="#2c3e50").pack(pady=(25, 8))
tk.Label(root, text="Seleziona il file odp_line_list.csv o .gz o .xlxs per generare i DTW", font=("Segoe UI", 10), bg="#f0f4f8", fg="#7f8c8d").pack(pady=(0, 20))

frame = tk.Frame(root, bg="#f0f4f8")
frame.pack(pady=10, padx=35, fill="both", expand=True)

btn_scegli = tk.Button(frame, text="SCEGLI FILE odp_line_list.csv / .gz / .xlxs", font=("Segoe UI", 11, "bold"), width=40, height=2, bg="#3498db", fg="white", relief="flat", cursor="hand2")
btn_scegli.pack(pady=15)

lbl_file = tk.Label(frame, text="Nessun file selezionato", font=("Segoe UI", 10), bg="#f0f4f8", fg="#95a5a6", wraplength=720)
lbl_file.pack(pady=(5, 15))

progress = ttk.Progressbar(frame, mode='determinate', length=720)
progress.pack(pady=10)

log_frame = tk.Frame(frame, bg="white", relief="sunken", bd=1)
log_frame.pack(pady=15, fill="both", expand=True)

log_text = tk.Text(log_frame, height=18, font=("Consolas", 9), bg="#fdfdfd", fg="#2c3e50", wrap="word")
log_text.pack(side="left", fill="both", expand=True, padx=5, pady=5)
scrollbar = tk.Scrollbar(log_frame, command=log_text.yview)
scrollbar.pack(side="right", fill="y")
log_text.config(yscrollcommand=scrollbar.set)

footer = tk.Label(root, text=f"Output: {output_folder} | DB: Database_Generatore.db | Log: ODP_NTD_Log.log", font=("Segoe UI", 8), bg="#f0f4f8", fg="#95a5a6")
footer.pack(side="bottom", pady=15)

csv_path = None
logger = None

# ========================
# INVIO MAIL – PASSWORD: xxx
# ========================
def invia_email_smtp(filepath, to="dizzo@atsgruppo.eu"):
    msg = MIMEMultipart()
    msg['From'] = "atssegnalazioni@gmail.com"
    msg['To'] = to
    msg['Subject'] = f"ODP Da Definire - {datetime.now():%d/%m/%Y}"

    with open(filepath, "rb") as f:
        part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
        msg.attach(part)

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("atssegnalazioni@gmail.com", "xxx")
            server.send_message(msg)
        logging.info("Email inviata via Gmail SMTP")
        return True
    except Exception as e:
        logging.error(f"SMTP fallito: {e}")
        return False

# ========================
# COLONNE DTW (COMPLETE)
# ========================
ordr_columns = [
    "DocNum","DocType","HandWritten","Printed","DocDate","DocDueDate","CardCode",
    "CardName","Address","NumAtCard","DocCurrency","DocRate","DocTotal","Reference1","Reference2",
    "Comments","JournalMemo","PaymentGroupCode","DocTime","SalesPersonCode","TransportationCode","Confirmed",
    "ImportFileNum","SummeryType","ContactPersonCode","ShowSCN","Series","TaxDate","PartialSupply",
    "DocObjectCode","ShipToCode","Indicator","FederalTaxID","DiscountPercent","PaymentReference",
    "DocTotalFC","Form1099","Box1099","RevisionPo","RequriedDate","CancelDate",
    "BlockDunning","Pick","PaymentMethod","PaymentBlock","PaymentBlockEntry","CentralBankIndicator","MaximumCashDiscount",
    "Project","ExemptionValidityDateFrom","ExemptionValidityDateTo","WareHouseUpdateType","Rounding","ExternalCorrectedDocNum","InternalCorrectedDocNum",
    "DeferredTax","TaxExemptionLetterNum","AgentCode","NumberOfInstallments","ApplyTaxOnFirstInstallment","VatDate",
    "DocumentsOwner","FolioPrefixString","FolioNumber","DocumentSubType","BPChannelCode","BPChannelContact",
    "Address2","PayToCode","ManualNumber","UseShpdGoodsAct","IsPayToBank","PayToBankCountry",
    "PayToBankCode","PayToBankAccountNo","PayToBankBranch","BPL_IDAssignedToInvoice","DownPayment","ReserveInvoice","LanguageCode",
    "TrackingNumber","PickRemark","ClosingDate","SequenceCode","SequenceSerial","SeriesString","SubSeriesString",
    "SequenceModel","UseCorrectionVATGroup","DpmAmnt","DownPaymentPercentage","DownPaymentType","DownPaymentAmountSC","DownPaymentAmountFC",
    "VatPercent","ServiceGrossProfitPercent","OpeningRemarks","ClosingRemarks","RoundingDiffAmount","ControlAccount",
    "InsuranceOperation347","ArchiveNonremovableSalesQuotation","U_Tipo","U_DataRic","U_OraRic","U_NumAtCard","GroupKey"
]

rdr1_columns = [
    "ParentKey","LineNum","ItemCode","ItemDescription","Quantity","ShipDate","Price","PriceAfterVAT",
    "Currency","Rate","DiscountPercent","VendorNum","SerialNum","WarehouseCode","SalesPersonCode","CommisionPercent",
    "TreeType","AccountCode","UseBaseUnits","SupplierCatNum","CostingCode","ProjectCode","BarCode","VatGroup",
    "Height1","Hight1Unit","Height2","Height2Unit","Lengh1","Lengh1Unit","Lengh2","Lengh2Unit",
    "Weight1","Weight1Unit","Weight2","Weight2Unit","Factor1","Factor2","Factor3","Factor4",
    "BaseType","BaseEntry","BaseLine","Volume","VolumeUnit","Width1","Width1Unit","Width2","Width2Unit",
    "Address","TaxCode","TaxType","TaxLiable","BackOrder","FreeText","ShippingMethod","CorrectionInvoiceItem",
    "CorrInvAmountToStock","CorrInvAmountToDiffAcct","WtLiable","DeferredTax","MeasureUnit","UnitsOfMeasurment",
    "LineTotal","TaxPercentagePerRow","TaxTotal","ConsumerSalesForecast","ExciseAmount","CountryOrg","SWW","TransactionType",
    "DistributeExpense","ShipToCode",
    "RowTotalFC","CFOPCode","CSTCode","Usage","TaxOnly","UnitPrice","LineStatus","LineType",
    "COGSCostingCode","COGSAccountCode","ChangeAssemlyBoMWarehouse","GrossBuyPrice","GrossBase",
    "GrossProfitTotalBasePrice","CostingCode2","CostingCode3","CostingCode4","CostingCode5",
    "ItemDetails","LocationCode","ActualDeliveryDate","ExLineNo","RequiredDate","RequiredQuantity",
    "COGSCostingCode2","COGSCostingCode3","COGSCostingCode4","COGSCostingCode5","WithoutInventoryMovement",
    "AgrementNo","AgreementRowNumber","ShipToDescription","U_PartNumber","U_CDC","U_IDScheda",
    "U_Location","U_PO","U_Posizione","U_ReqDate","U_TargaTecnica","U_Office","U_SpecIns","U_IDLav","U_CDInt","GroupKey","Motivo_Errore","U_MOLO","U_Sloc","U_WBS"
]

ordr_header_sap = [
    "DocNum","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode",
    "CardName","Address","NumAtCard","DocCur","DocRate","DocTotal","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed",
    "ImportEnt","SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply",
    "ObjType","ShipToCode","Indicator","LicTradNum","DiscPrcnt","PaymentRef",
    "DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate","CancelDate",
    "BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn",
    "Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate",
    "OwnerCode","FolioPref","FolioNum","DocSubType","BPChCode","BPChCntc",
    "Address2","PayToCode","ManualNumber","UseShpdGd","IsPaytoBnk","BnkCntry",
    "BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode",
    "TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr",
    "Model","UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC",
    "VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount",
    "InsurOp347","IgnRelDoc","U_Tipo","U_DataRic","U_OraRic","U_NumAtCard"
]

rdr1_header_sap = [
    "DocNum","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT",
    "Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SubCatNum","OcrCode","Project","CodeBars","VatGroup",
    "Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4",
    "BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag",
    "ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","ShipToCode",
    "TotalFrgn","CFOPCode","CSTCode","Usage","TaxOnly","PriceBefDi","LineStatus","LineType",
    "CogsOcrCod","CogsAcct","ChgAsmBoMW","GrossBuyPr","GrossBase","GPTtlBasPr","OcrCode2",
    "OcrCode3","OcrCode4","OcrCode5","Text","LocCode","ActDelDate","ExLineNo","PQTReqDate",
    "PQTReqQty","CogsOcrCo2","CogsOcrCo3","CogsOcrCo4","CogsOcrCo5","NoInvtryMv","AgrNo",
    "AgrLnNum","ShipToDesc","U_PartNumber","U_CDC","U_IDScheda","U_Location","U_PO","U_Posizione",
    "U_ReqDate","U_TargaTecnica","U_Office","U_SpecIns","U_IDLav","U_CDInt","U_MOLO","U_Sloc","U_WBS"
]

# ========================
# ELABORAZIONE
# ========================
def avvia_elaborazione():
    global csv_path, logger
    if not csv_path:
        messagebox.showerror("Errore", "Seleziona un file!")
        return

    logger = GUILogger(log_text)
    sys.stdout = logger
    log_text.delete(1.0, tk.END)

    def run():
        try:
            progress['value'] = 0
            root.update()

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            # ==================================================================
            # LETTURA INTELLIGENTE DEL FILE (CSV, CSV.GZ, XLSX, XLS)
            # ==================================================================
            print(f"File selezionato: {csv_path}")
            progress['value'] = 5
            root.update()

            file_lower = csv_path.lower()
            temp_csv_path = None

            try:
                if file_lower.endswith(".gz"):
                    # File compresso .csv.gz
                    with gzip.open(csv_path, 'rb') as f_in:
                        content = f_in.read()
                    # Decomprimo in memoria o su disco
                    temp_csv_path = os.path.join(base_path, f"temp_decompress_{timestamp}.csv")
                    with open(temp_csv_path, 'wb') as f_out:
                        f_out.write(content)
                    file_to_read = temp_csv_path

                elif file_lower.endswith((".xlsx", ".xls")):
                    # File Excel → convertiamo in DataFrame direttamente
                    print("Rilevato file Excel → lettura con pandas...")
                    # engine='openpyxl' per .xlsx, 'xlrd' per .xls (vecchio)
                    engine = 'openpyxl' if file_lower.endswith('.xlsx') else 'xlrd'
                    xl = pd.ExcelFile(csv_path, engine=engine)
                    print(f"Fogli disponibili: {xl.sheet_names}")
                    
                    # Usa il primo foglio (o puoi far scegliere all'utente in futuro)
                    sheet_name = xl.sheet_names[0]
                    print(f"Lettura del foglio: {sheet_name}")
                    
                    df = xl.parse(sheet_name=sheet_name, dtype=str).fillna("")
                    print(f"Lette {len(df)} righe dal foglio Excel '{sheet_name}'.")
                    
                    # Salta eventuali righe completamente vuote all'inizio
                    df = df.dropna(how='all').reset_index(drop=True)
                    
                    progress['value'] = 15
                    root.update()
                    # Salta il resto del blocco: df è già pronto!
                    pass  

                else:
                    # File CSV normale
                    file_to_read = csv_path

                # =========================================================
                # Se non era Excel, leggiamo come CSV (con separatore intelligente)
                # =========================================================
                if 'df' not in locals():  # cioè non abbiamo già letto un Excel
                    # Prova prima con punto e virgola, poi con virgola, tab, ecc.
                    sep = ';'
                    with open(file_to_read, 'r', encoding='utf-8-sig') as f:
                        prima_riga = f.readline()
                        if ';' in prima_riga and ',' not in prima_riga:
                            sep = ';'
                        elif ',' in prima_riga:
                            sep = ','
                        elif '\t' in prima_riga:
                            sep = '\t'
                        else:
                            sep = ';'  # fallback

                    print(f"Lettura CSV con separatore: '{sep}'")
                    df = pd.read_csv(file_to_read, dtype=str, sep=sep, engine='python', on_bad_lines='warn').fillna("")
                    print(f"Lette {len(df)} righe dal file CSV.")

                progress['value'] = 15
                root.update()

            finally:
                # Pulizia file temporaneo se creato
                if temp_csv_path and os.path.exists(temp_csv_path):
                    try: os.remove(temp_csv_path)
                    except: pass

            
            ordr_out = os.path.join(output_folder, f"ORDR_{timestamp}.csv")
            rdr1_out = os.path.join(output_folder, f"RDR1_{timestamp}.csv")
            da_definire_out = os.path.join(output_folder, f"ODP_Da_Definire_{timestamp}.csv")

            print(f"Lette {len(df)} righe dal file.")
            progress['value'] = 10
            root.update()

            df = df.rename(columns={
                "MRN No": "NumODP",
                "Req Date": "DataODP",
                "Qty": "Qta",
                "Material": "CodiceMateriale",
                "Site Operator/ DP Name": "NomeShipto",
                "Forecast Installation Date": "PrevCons",
                "Receiving Warehouse": "PODeliveryDate",
                "Plant": "Plant",
                "ZZ_POITEM": "PosPO",
                #"ZZ_NWLOC": "TargaSito" ---- sostituito da Location ---
                "Location": "Location",
                "ZZ_PO": "NumPO",
                "Text": "SchedaSito",
                "Security/Engineer Contact":"Office",
                "Special Ins":"SpecialIns",
                "ID Intervento": "CDInt",
                "ID Lavorazione NPLUS": "IDLav",
                "Targa tecnica":"TargaTecnica",
            }, errors="ignore")
            def parse_date_safe(val):
                if not val or str(val).strip() == "":
                   return pd.NaT
                return pd.to_datetime(val, errors="coerce")

            df["DataODP_dt"] = df["DataODP"].apply(parse_date_safe)

            # <<< AGGIUNTO QUESTO BLOCCO PER POPOLARE NUM ODP <<<
            # Popola NumODP con l'ultima parte di SchedaSito dopo l'ultimo "|", se NumODP è vuoto
            mask_vuota = (df["NumODP"].astype(str).str.strip() == "") | (df["NumODP"].isna())
            if "SchedaSito" in df.columns:
                # Estrae l'ultima parte dopo l'ultimo pipe (e pulisce spazi)
                ultima_parte = df["SchedaSito"].astype(str).str.split("|").str[-1].str.strip()
                # Solo dove NumODP era vuoto, sovrascrivi con questo valore
                df.loc[mask_vuota, "NumODP"] = ultima_parte.loc[mask_vuota]
            # >>> FINE BLOCCO <<<

            # TEMPORANEO: NomeShipto derivato da SchedaSito (da rimuovere quando si torna alla logica standard)
            df["NomeShipto"] = df["SchedaSito"].astype(str).str.split("|").str[0].str.strip()

            # Salviamo la versione completa di "Req Date" (data+ora) prima di convertirla
            # (la colonna originale si chiama ancora "DataODP" a questo punto)
            df["ReqDate_Completa"] = df["DataODP"].astype(str).str.strip()

            # Pulizia opzionale: se è già in formato italiano con ora, la lasciamo così
            # Altrimenti proviamo a convertirla in dd/mm/yyyy hh:mm
            def formatta_data_ora(val):
                if not val or val in ("", "nan"):
                    return ""
                val = str(val).strip()
                # Se ha già l'ora, la teniamo così com'è (es. 15/03/2025 14:30)
                if " " in val and len(val) >= 17:
                    return val[:17]  # taglia eventuali secondi o fuso
                # Altrimenti proviamo a parsare e riformattare
                try:
                    dt = pd.to_datetime(val, dayfirst=True, errors="coerce")
                    if pd.notna(dt):
                        return dt.strftime("%d/%m/%Y %H:%M")
                except:
                    pass
                return val  # fallback: lascia com'è
            df["ReqDate_Completa"] = df["ReqDate_Completa"].apply(formatta_data_ora)
            # <<< Fine blocco >>>

            if "PODeliveryDate" not in df.columns:
                df["PODeliveryDate"] = ""
            if "PrevCons" not in df.columns:
                df["PrevCons"] = ""
            if "NumPO" not in df.columns:
                df["NumPO"] = ""
            if "PosPO" not in df.columns:
                df["PosPO"] = ""        
            # Campi UDF riga RDR1: Sloc -> U_Sloc, WBS -> U_WBS
            for col in ("Sloc", "WBS"):
                if col not in df.columns:
                    print(f"Attenzione: colonna '{col}' non trovata nel file.")
                    df[col] = ""
                df[col] = df[col].astype(str).str.strip()

            df["NumODP"] = df["NumODP"].astype(str).str.strip()
            df["Qta"] = pd.to_numeric(df["Qta"], errors="coerce").fillna(0).astype(int)
            df["CodiceMateriale"] = df["CodiceMateriale"].astype(str).str.strip()

            #copia_path = os.path.join(base_path, f"odp_line_list_usato_{timestamp}.csv")
            #shutil.copy(csv_path_local, copia_path)
            #print(f"Copia del file usato salvata: {copia_path}")
            progress['value'] = 15
            root.update()

            conn = sqlite3.connect(db_path)
            conn.execute("""
            CREATE TABLE IF NOT EXISTS StoricoOdpNTD (
                NumODP TEXT, DataODP TEXT, Qta TEXT, CodiceMateriale TEXT,
                MaxLineNum INTEGER, DataCaricamento TEXT, group_key TEXT
            )
            """)
            conn.commit()

            storico_df = pd.read_sql_query("SELECT * FROM StoricoOdpNTD;", conn).fillna("")
            max_linenum_dict = {}
            storico_records = set()
            if not storico_df.empty:
                for _, row in storico_df.iterrows():
                    if pd.notna(row.get("NumODP")) and pd.notna(row.get("DataODP")) and pd.notna(row.get("Qta")) and pd.notna(row.get("CodiceMateriale")):
                        quintupla = (str(row["NumODP"]), str(row["DataODP"]), str(row["Qta"]), str(row["CodiceMateriale"]), str(row.get("group_key", "")))
                        storico_records.add(quintupla)
                    NumODP = str(row["NumODP"])
                    linenum = int(row["MaxLineNum"]) if row.get("MaxLineNum") not in (None, "") else 0
                    max_linenum_dict[NumODP] = max(max_linenum_dict.get(NumODP, -1), linenum)

            conv_depositi = pd.read_sql_query("SELECT * FROM 'Conversione Depositi NSS';", conn).fillna("")
            if "CONVERSIONE_SHIP_TO" in conv_depositi.columns:
                conv_depositi["CONVERSIONE_SHIP_TO"] = conv_depositi["CONVERSIONE_SHIP_TO"].astype(str).str.strip().str.upper()

            anagrafica = pd.read_sql_query("""
                SELECT * FROM "Anagrafica_SAP" WHERE "Codice Articolo (ATS)" LIKE '%-NTD'
            """, conn).fillna("")
            if "Material SAP Code (BP)" in anagrafica.columns:
                anagrafica["Material SAP Code (BP)"] = anagrafica["Material SAP Code (BP)"].astype(str).str.strip()

            cdc_map = pd.read_sql_query("SELECT * FROM 'OPORCodificaCodSap';", conn).fillna("")
            cdc_dict = dict(zip(cdc_map["NameCDC"], cdc_map["CodeCDC"])) if "NameCDC" in cdc_map.columns and "CodeCDC" in cdc_map.columns else {}

            def get_Shipto(nome_fornitore):
                key = str(nome_fornitore).strip().upper()
                if not conv_depositi.empty and "CONVERSIONE_SHIP_TO" in conv_depositi.columns:
                    row = conv_depositi[conv_depositi["CONVERSIONE_SHIP_TO"] == key]
                    return row.iloc[0].get("nome_dtw", "NON DEFINITO") if not row.empty else "NON DEFINITO"
                return "NON DEFINITO"

            def get_CodeShipto(nome_fornitore):
                key = str(nome_fornitore).strip().upper()
                if not conv_depositi.empty and "CONVERSIONE_SHIP_TO" in conv_depositi.columns:
                    row = conv_depositi[conv_depositi["CONVERSIONE_SHIP_TO"] == key]
                    return row.iloc[0].get("codice_dtw", "NON DEFINITO") if not row.empty else "NON DEFINITO"
                return "NON DEFINITO"

            def get_itemcode(codice_materiale):
                if not anagrafica.empty and "Material SAP Code (BP)" in anagrafica.columns:
                    row = anagrafica[anagrafica["Material SAP Code (BP)"] == codice_materiale]
                    return row.iloc[0].get("Codice articolo (ATS)", "DA DEFINIRE") if not row.empty else "DA DEFINIRE"
                return "DA DEFINIRE"

            def get_partnumber(codice_materiale):
                if not anagrafica.empty and "Material SAP Code (BP)" in anagrafica.columns:
                    row = anagrafica[anagrafica["Material SAP Code (BP)"] == codice_materiale]
                    return row.iloc[0].get("part number", "") if not row.empty else ""
                return ""

            def get_cdc(plant):
                return cdc_dict.get(str(plant).strip(), "0")
            
            config = load_config()
            def get_whscode_by_cdc(cdc_val):
                cdc_val = str(cdc_val).strip()

                for whs, cdc_list in config.get("warehouse_by_cdc", {}).items():
                    if cdc_val in map(str, cdc_list):
                       return whs

                return config.get("warehouse_default", "")
            
            def build_ordr_row(group_key, first_row, ShipTo, CodeShipTo):
                if pd.notna(first_row["DataODP_dt"]):
                    docdate_csv = first_row["DataODP_dt"].strftime("%Y%m%d")
                else:
                    docdate_csv = datetime.today().strftime("%Y%m%d")

                commenti = f"Req Date: {first_row['ReqDate_Completa']}"
                if first_row["PrevCons"]:
                    commenti += f" | Forecast Installation Date: {first_row['PrevCons']}"
                elif first_row["PODeliveryDate"]:
                    commenti += f" | PO Delivery Date: {first_row['PODeliveryDate']}"

                     # Estrazione DocTime da ReqDate_Completa # Estrazione DocTime da ReqDate_Completa → formato HHMM (4 cifre)
                doc_time = None
                if first_row.get('ReqDate_Completa'):
                   match = re.search(r'(\d{2}):(\d{2})', first_row['ReqDate_Completa'])
                   if match:
                       hour = int(match.group(1))
                       minute = int(match.group(2))
                       doc_time = f"{hour:02d}{minute:02d}"

# Fallback: ora corrente
                if doc_time is None:
                   now = datetime.now()
                   doc_time = f"{now.hour:02d}{now.minute:02d}"

                # TransportationCode sicuro
                transportation_code = ""
                scheda = str(first_row.get("SchedaSito", ""))
                if "|" in scheda:
                    parti = scheda.split("|", 2)
                    if len(parti) >= 2:
                        transportation_code = parti[1].strip()
                mapping = {
                    "Standard": 1,
                    "Espresso": 2,
                    "Dedicato": 3
                }

                transportation_code = mapping.get(transportation_code, 0)

                row = {col: "" for col in ordr_columns}
                row.update({
                    "DocNum": docNum, "DocType": "dDocument_Items", "DocDate": docdate_csv,
                    "DocDueDate": docdate_csv, "CardCode": config["ordr_defaults"].get("CardCode", ""), "NumAtCard": first_row["NumODP"],
                    "Comments": commenti,"DocTime": doc_time , "TransportationCode": transportation_code,
                    "Series": int(config["ordr_defaults"].get("Series", 0)), "TaxDate": docdate_csv, "Project": config["ordr_defaults"].get("Project", ""),
                    "ShipToCode": ShipTo,
                    "U_Tipo": config["ordr_defaults"].get("U_Tipo", ""),"U_DataRic":docdate_csv,"U_OraRic": doc_time ,"U_NumAtCard": ShipTo, "GroupKey": group_key
                })
                return row, docdate_csv  


            def build_rdr1_row(docNum, lineNum, df_row, cdc_val, item_code, partnum, group_key, docdate_csv, motivo=None):
                # Accesso sicuro sia per namedtuple che per dict
                def val(field, default=""):
                    if isinstance(df_row, dict):
                        return df_row.get(field, default)
                    else:
                        return getattr(df_row, field, default)

                scheda = str(val("SchedaSito", ""))
                u_idscheda = scheda.split("|")[-1].strip() if "|" in scheda else ""
                u_location = scheda.split("|", 1)[0].strip() if "|" in scheda else ""

                rdr1_row = {col: "" for col in rdr1_columns}
                rdr1_row.update({
                    "ParentKey": docNum,
                    "LineNum": lineNum,
                    "ItemCode": item_code,
                    "Quantity": val("Qta", 0),
                    "WarehouseCode": get_whscode_by_cdc(cdc_val),
                    "SupplierCatNum": val("CodiceMateriale"),
                    "ProjectCode": config["rdr1_defaults"].get("ProjectCode", ""),
                    "U_PartNumber": partnum,
                    "U_CDC": cdc_val,
                    "U_IDScheda": u_idscheda,
                    "U_Location": val("TargaTecnica"),
                    "U_PO": val("NumPO"),
                    "U_Posizione": val("PosPO"),
                    "U_ReqDate": docdate_csv,
                    #"U_TargaTecnica": val("TargaTecnica"),
                    "U_Office":val("Office"),
                    "U_SpecIns":val("SpecialIns"),
                    "U_IDLav":val("IDLav"),
                    "U_CDInt":val("CDInt"),
                    "U_MOLO":u_idscheda,
                    "U_Sloc": val("Sloc"),
                    "U_WBS": val("WBS"),
                    "GroupKey": group_key
                })
                if motivo:
                    rdr1_row["Motivo_Errore"] = motivo
                return rdr1_row

            #df["group_key"] = df.apply(lambda r: f"{r['NumODP']}_{r['PrevCons'] if r['PrevCons'] else r['PODeliveryDate']}", axis=1)
            df["group_key"] = df["NumODP"]

            ordr_list, rdr1_list, da_definire_list = [], [], []
            docNum = 1001
            nuove_righe_storico = []

            total_groups = len(df["group_key"].unique())
            processed = 0

            print("\n" + "="*60)
            print("INIZIO ELABORAZIONE ORDINI")
            print(f"Trovati {total_groups} gruppi da elaborare")
            print("="*60 + "\n")

            for group_key, group in df.groupby("group_key", sort=False):
                processed += 1
                first_row = group.iloc[0]

                print(f"[{processed}/{total_groups}] → NumODP: {first_row['NumODP']} | Righe: {len(group)} | Data: {first_row['DataODP']}")

                ShipTo = get_Shipto(first_row["NomeShipto"])
                CodeShipTo = get_CodeShipto(first_row["NomeShipto"])
                print(f"     ShipTo rilevato → {ShipTo}")

                has_undefined = any(
                    get_itemcode(r.CodiceMateriale) == "DA DEFINIRE" or ShipTo == "NON DEFINITO"
                    or not str(r.WBS).strip()
                    for r in group.itertuples(index=False)
                )

                ordr_row, docdate_csv = build_ordr_row(group_key, first_row, ShipTo, CodeShipTo)
                rdr1_temp, da_def_temp = [], []
                lineNum = max_linenum_dict.get(first_row["NumODP"], -1) + 1
                righe_aggiunte = 0

                for r in group.itertuples(index=False):
                    quintupla = (r.NumODP, r.DataODP, str(r.Qta), r.CodiceMateriale, group_key)
                    if quintupla in storico_records:
                        continue

                    item_code = get_itemcode(r.CodiceMateriale)
                    partnum = get_partnumber(r.CodiceMateriale)
                    cdc_val = get_cdc(r.Plant)
                    print(f"DEBUG → CDC {cdc_val} → Warehouse {get_whscode_by_cdc(cdc_val)}")
                    lineNum += 1

                    motivo = []
                    if item_code == "DA DEFINIRE":
                        motivo.append(f"Materiale non trovato: {r.CodiceMateriale}")
                    if ShipTo == "NON DEFINITO":
                        motivo.append(f"ShipTo non definito: {r.NomeShipto}")
                    if not str(r.WBS).strip():
                        motivo.append("WBS mancante")
                    motivo = ", ".join(motivo) if motivo else None

                    rdr1_row = build_rdr1_row(docNum, lineNum, r, cdc_val, item_code, partnum, group_key, docdate_csv, motivo)

                    if has_undefined:
                        riga_completa = {**ordr_row, **rdr1_row}
                        da_def_temp.append(riga_completa)
                    else:
                        rdr1_temp.append(rdr1_row)
                        righe_aggiunte += 1
                        oggi = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                        nuove_righe_storico.append({
                            "NumODP": r.NumODP, "DataODP": r.DataODP, "Qta": r.Qta,
                            "CodiceMateriale": r.CodiceMateriale, "MaxLineNum": rdr1_row["LineNum"],
                            "DataCaricamento": oggi, "group_key": group_key
                        })
                        max_linenum_dict[r.NumODP] = rdr1_row["LineNum"]

                if not has_undefined and rdr1_temp:
                    ordr_list.append(ordr_row)
                    rdr1_list.extend(rdr1_temp)
                    docNum += 1
                    print(f"     ORDINE CREATO ({righe_aggiunte} righe aggiunte)\n")
                else:
                    da_definire_list.extend(da_def_temp)
                    motivo_finale = "Materiale mancante" if any(get_itemcode(r.CodiceMateriale) == "DA DEFINIRE" for r in group.itertuples(index=False)) else (
                        "WBS mancante" if any(not str(r.WBS).strip() for r in group.itertuples(index=False)) else "ShipTo non definito"
                    )
                    print(f"     SPOSTATO IN 'Da Definire' → {motivo_finale}\n")

                percent = int((processed / total_groups) * 100) if total_groups > 0 else 100
                progress['value'] = 20 + (percent * 0.6)
                root.update()
            
            print(f"\nELABORAZIONE COMPLETATA")
            print(f"  → Ordini creati: {len(ordr_list)}")
            print(f"  → Righe RDR1: {len(rdr1_list)}")
            print(f"  → In 'Da Definire': {len(da_definire_list)}")
            print("="*60 + "\n")
            
            def write_csv_with_second_header(df_list, filepath, second_header, is_da_definire=False):
                df = pd.DataFrame(df_list)
                df = df.astype(str)
                if not is_da_definire:
                    for col in ['GroupKey', 'Motivo_Errore']:
                        if col in df.columns:
                            df = df.drop(columns=[col])
                else:
                    df = df.dropna(axis=1, how='all')
                df = df.apply(lambda col: col.str.replace(",", " | ", regex=False))    
                with open(filepath, "w", encoding="utf-8-sig", newline="") as f:
                    f.write(",".join(df.columns) + "\n")
                    f.write(",".join(second_header[:len(df.columns)]) + "\n")
                    df.to_csv(f, index=False, header=False, sep=",", mode='a')

            if ordr_list:
                write_csv_with_second_header(ordr_list, ordr_out, ordr_header_sap)
                print(f"File ORDR generato: {ordr_out}")

            if rdr1_list:
                write_csv_with_second_header(rdr1_list, rdr1_out, rdr1_header_sap)
                print(f"File RDR1 generato: {rdr1_out}")

            if da_definire_list:
                write_csv_with_second_header(da_definire_list, da_definire_out, rdr1_header_sap + ["Motivo_Errore"], is_da_definire=True)
                print(f"File ODP_Da_Definire generato: {da_definire_out}")

            if not ordr_list and not rdr1_list and not da_definire_list:
                print("Nessun nuovo ordine da elaborare: tutti i PO erano già presenti nello storico.")
            else:
                if ordr_list or rdr1_list:
                    print("Template ORDR e RDR1 Creati Con Successo.")
                if da_definire_list:
                    print("Attenzione: sono state trovate incongruenze, controllare il file ODP_Da_Definire.")

            if os.path.exists(da_definire_out):
                df_def = pd.read_csv(da_definire_out, dtype=str, header=None).fillna("")
                if len(df_def) > 1:
                    df_def = df_def.drop(index=1).reset_index(drop=True)
                df_def = df_def.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                if len(df_def) > 1:
                    dati = df_def.iloc[1:]
                    non_empty_cols = dati.columns[(dati.replace("", pd.NA).notna()).any(axis=0)]
                    df_def = df_def[non_empty_cols]
                df_def.to_csv(da_definire_out, index=False, header=False, sep=",")
                print(f"Attenzione Sono Stati Trovate Delle Incongruenze , File Generato : {da_definire_out}")
                invia_email_smtp(da_definire_out)
            else:
                print("Se Presenti ODP Nuovi , I Template ORDR e RDR1 Sono Stati Creati Con Successo , Nessuna Incongruenza Trovata!")

            if nuove_righe_storico:
                df_nuove = pd.DataFrame(nuove_righe_storico)
                df_nuove.to_sql("StoricoOdpNTD", conn, if_exists="append", index=False)
                conn.commit()
                print("Storico aggiornato con i nuovi ODP definiti (DB).")
            else:
                print("Nessuna nuova riga da salvare nello storico.")

            conn.close()
            progress['value'] = 100
            messagebox.showinfo("Completato", f"Elaborazione terminata!\nFile in:\n{output_folder}")

        except Exception as e:
            messagebox.showerror("Errore", f"{e}")
        finally:
            if 'conn' in locals():
                conn.close()

    Thread(target=run, daemon=True).start()

def scegli_file():
    global csv_path
    file = filedialog.askopenfilename(
        title="Seleziona il file ODP da elaborare Csv o Excel o gz",
        filetypes=[("Tutti i file supportati", "*.csv *.CSV *.csv.gz *.CSV.GZ *.xlsx *.XLSX *.xls *.XLS"),
        ("File CSV", "*.csv *.CSV"),
        ("File CSV compressi", "*.csv.gz *.CSV.GZ"),
        ("File Excel", "*.xlsx *.XLSX *.xls *.XLS"),
        ("Tutti i file", "*.*")]
    )
    if file: 
        csv_path = file
        lbl_file.config(text=f"File: {os.path.basename(file)}", fg="#27ae60")
        btn_scegli.config(text="AVVIA ELABORAZIONE", command=avvia_elaborazione, bg="#27ae60")

btn_scegli.config(command=scegli_file)
root.mainloop()