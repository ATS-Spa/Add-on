# Aggiornamento_Database_GUI.py
import os
import sys
import pandas as pd
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

# === RISOLUZIONE PERCORSO (FUNZIONA ANCHE COME .EXE) ===
if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent

DB_PATH = BASE_DIR / "Database_Generatore.db"
TABELLA = "Anagrafica_SAP"
COLONNA_CODICE = "Codice articolo (ATS)"

# === FUNZIONI ===
def scegli_file_excel():
    file_path = filedialog.askopenfilename(
        title="Seleziona il file Excel da importare",
        filetypes=[("File Excel", "*.xlsx *.xls")],
        parent=root
    )
    return file_path

def leggi_excel(file_path):
    try:
        df = pd.read_excel(file_path, engine='openpyxl' ,dtype={
                "Material SAP Code (BP)": str,
                "Codice articolo (ATS)": str
            })
        return df, None
    except Exception as e:
        return None, f"Errore lettura Excel:\n{e}"

def verifica_database():
    if not DB_PATH.exists():
        return False, f"Database non trovato:\n{DB_PATH.name}"
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.close()
        return True, ""
    except:
        return False, "Impossibile connettersi al database."

def aggiorna_database(df):
    try:
        df["Material SAP Code (BP)"] = (
            df["Material SAP Code (BP)"]
            .astype(str)
            .str.strip()
        )
        df[COLONNA_CODICE] = (
            df[COLONNA_CODICE]
            .astype(str)
            .str.strip()
        )
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute(f"SELECT [{COLONNA_CODICE}] FROM [{TABELLA}]")
        codici_db = {row[0] for row in c.fetchall() if row[0]}

        if COLONNA_CODICE not in df.columns:
            conn.close()
            return False, f"Colonna mancante nel file Excel:\n'{COLONNA_CODICE}'"

        df_nuovi = df[~df[COLONNA_CODICE].isin(codici_db)].copy()
        df_nuovi = df_nuovi.dropna(subset=[COLONNA_CODICE])

        if df_nuovi.empty:
            conn.close()
            return True, "Nessun nuovo articolo da inserire.", []

        df_nuovi.to_sql(TABELLA, conn, if_exists='append', index=False)
        nuovi_codici = df_nuovi[COLONNA_CODICE].astype(str).tolist()
        conn.close()
        return True, f"Inseriti {len(nuovi_codici)} nuovi articoli.", nuovi_codici

    except Exception as e:
        return False, f"Errore durante l'aggiornamento:\n{e}", []

# === INTERFACCIA GRAFICA ===
root = tk.Tk()
root.title("Aggiornamento Anagrafica Database")
root.geometry("620x520")
root.resizable(False, False)
root.configure(bg="#f4f6f9")

# Stile
style = ttk.Style()
style.theme_use('clam')

# Titolo
tk.Label(
    root,
    text="AGGIORNAMENTO ANAGRAFICA",
    font=("Segoe UI", 18, "bold"),
    bg="#f4f6f9",
    fg="#2c3e50"
).pack(pady=(25, 8))

tk.Label(
    root,
    text="Carica un file Excel per aggiornare il database SAP",
    font=("Segoe UI", 10),
    bg="#f4f6f9",
    fg="#7f8c8d"
).pack(pady=(0, 25))

# Frame principale
frame = tk.Frame(root, bg="#f4f6f9")
frame.pack(pady=10, padx=40, fill="both", expand=True)

# Stato Database
db_ok, db_msg = verifica_database()
status_color = "#27ae60" if db_ok else "#e74c3c"
status_text = "Database trovato e accessibile" if db_ok else "DATABASE NON TROVATO"

lbl_db = tk.Label(
    frame,
    text=f"Database: {status_text}",
    font=("Segoe UI", 10, "bold"),
    fg=status_color,
    bg="#f4f6f9"
)
lbl_db.pack(pady=(0, 15))

if not db_ok:
    tk.Label(
        frame,
        text=db_msg,
        font=("Segoe UI", 9),
        fg="#e74c3c",
        bg="#f4f6f9",
        wraplength=500,
        justify="center"
    ).pack(pady=(0, 20))

# Pulsante scelta file
btn_scegli = tk.Button(
    frame,
    text="SCEGLI FILE EXCEL",
    font=("Segoe UI", 11, "bold"),
    width=30,
    height=2,
    bg="#3498db",
    fg="white",
    activebackground="#2980b9",
    relief="flat",
    cursor="hand2",
    command=lambda: avvia_importazione()
)
btn_scegli.pack(pady=15)

# Area risultato
result_frame = tk.Frame(frame, bg="#f4f6f9")
result_frame.pack(pady=20, fill="both", expand=True)

lbl_risultato = tk.Label(
    result_frame,
    text="Nessuna operazione eseguita.",
    font=("Segoe UI", 10),
    bg="#f4f6f9",
    fg="#7f8c8d",
    wraplength=540,
    justify="left"
)
lbl_risultato.pack(anchor="w", pady=(0, 10))

listbox = tk.Listbox(
    result_frame,
    height=8,
    font=("Consolas", 9),
    bg="white",
    relief="sunken",
    selectbackground="#3498db"
)
listbox.pack(fill="both", expand=True, pady=(0, 10))
scrollbar = tk.Scrollbar(listbox)
scrollbar.pack(side="right", fill="y")
listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)

# Footer
footer = tk.Label(
    root,
    text=f"Database: {DB_PATH.name}\n"
         "Tutti i file devono essere nella stessa cartella | Versione 1.0",
    font=("Segoe UI", 8),
    bg="#f4f6f9",
    fg="#95a5a6",
    justify="center"
)
footer.pack(side="bottom", pady=15)

# === FUNZIONE PRINCIPALE ===
def avvia_importazione():
    # Resetta
    lbl_risultato.config(text="Caricamento file in corso...", fg="#7f8c8d")
    listbox.delete(0, tk.END)
    root.update()

    # 1. Scegli file
    file_excel = scegli_file_excel()
    if not file_excel:
        lbl_risultato.config(text="Nessun file selezionato.", fg="#e67e22")
        return

    lbl_risultato.config(text=f"File selezionato:\n{os.path.basename(file_excel)}", fg="#3498db")
    root.update()

    # 2. Leggi Excel
    df, errore = leggi_excel(file_excel)
    if errore:
        lbl_risultato.config(text=errore, fg="#e74c3c")
        return

    # 3. Aggiorna DB
    success, msg, codici = aggiorna_database(df)
    if success:
        lbl_risultato.config(text=msg, fg="#27ae60")
        if codici:
            listbox.insert(tk.END, "NUOVI ARTICOLI INSERITI:")
            listbox.insert(tk.END, "-" * 40)
            for codice in codici[:50]:  # max 50
                listbox.insert(tk.END, f"• {codice}")
            if len(codici) > 50:
                listbox.insert(tk.END, f"... e altri {len(codici)-50} articoli.")
        else:
            listbox.insert(tk.END, "Nessun nuovo record.")
    else:
        lbl_risultato.config(text=msg, fg="#e74c3c")

# Avvio
root.mainloop()