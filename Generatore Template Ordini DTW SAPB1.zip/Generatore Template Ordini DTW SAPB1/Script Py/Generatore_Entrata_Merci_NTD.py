# -*- coding: utf-8 -*-
"""
Generatore Entrata Merci NTD - Interfaccia Grafica
Converte il form di ricevimento (Excel) nei 5 file DTW per SAP B1:
ODLN (testata), DLN1 (righe), SRNT (seriali), BTNT (lotti), BINLOCATION (ubicazioni).

Configurazione esterna: ConfigEntrataMerci.json (creato al primo avvio accanto all'eseguibile).
"""

import os
import sys
import json
import traceback
from datetime import datetime, date
from collections import OrderedDict, defaultdict
from threading import Thread

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import openpyxl
from openpyxl.styles import Font, PatternFill

APP_TITLE = "Generatore Entrata Merci NTD"
CONFIG_NAME = "ConfigEntrataMerci.json"


def app_dir():
    """Cartella dell'eseguibile (PyInstaller) o dello script."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


CONFIG_PATH = os.path.join(app_dir(), CONFIG_NAME)
LOG_PATH = os.path.join(app_dir(), "EM_NTD_Log.log")
OUTPUT_FOLDER = os.path.join(app_dir(), "DTWEntrataMerciOutputNTD")

# ============================================================
# TRACCIATI DTW (riga 1 = nomi SDK, riga 2 = nomi DB)
# Copiati dai template validati in DTW: non modificare l'ordine.
# ============================================================
ODLN_SDK = [
    'DocNum', 'DocType', 'HandWritten', 'Printed', 'DocDate', 'DocDueDate', 'CardCode', 'CardName',
    'Address', 'NumAtCard', 'DocCurrency', 'DocRate', 'DocTotal', 'Reference1', 'Reference2',
    'Comments', 'JournalMemo', 'PaymentGroupCode', 'DocTime', 'SalesPersonCode',
    'TransportationCode', 'Confirmed', 'ImportFileNum', 'SummeryType', 'ContactPersonCode',
    'ShowSCN', 'Series', 'TaxDate', 'PartialSupply', 'DocObjectCode', 'ShipToCode', 'Indicator',
    'FederalTaxID', 'DiscountPercent', 'PaymentReference', 'DocTotalFc', 'Form1099', 'Box1099',
    'RevisionPo', 'RequriedDate', 'CancelDate', 'BlockDunning', 'Pick', 'PaymentMethod',
    'PaymentBlock', 'PaymentBlockEntry', 'CentralBankIndicator', 'MaximumCashDiscount', 'Project',
    'ExemptionValidityDateFrom', 'ExemptionValidityDateTo', 'WareHouseUpdateType', 'Rounding',
    'ExternalCorrectedDocNum', 'InternalCorrectedDocNum', 'DeferredTax', 'TaxExemptionLetterNum',
    'AgentCode', 'NumberOfInstallments', 'ApplyTaxOnFirstInstallment', 'VatDate', 'DocumentsOwner',
    'FolioPrefixString', 'FolioNumber', 'DocumentSubType', 'BPChannelCode', 'BPChannelContact',
    'Address2', 'PayToCode', 'ManualNumber', 'UseShpdGoodsAct', 'IsPayToBank', 'PayToBankCountry',
    'PayToBankCode', 'PayToBankAccountNo', 'PayToBankBranch', 'BPL_IDAssignedToInvoice',
    'DownPayment', 'ReserveInvoice', 'LanguageCode', 'TrackingNumber', 'PickRemark', 'ClosingDate',
    'SequenceCode', 'SequenceSerial', 'SeriesString', 'SubSeriesString', 'SequenceModel',
    'UseCorrectionVATGroup', 'DownPaymentAmount', 'DownPaymentPercentage', 'DownPaymentType',
    'DownPaymentAmountSC', 'DownPaymentAmountFC', 'VatPercent', 'ServiceGrossProfitPercent',
    'OpeningRemarks', 'ClosingRemarks', 'RoundingDiffAmount', 'ControlAccount',
    'InsuranceOperation347', 'ArchiveNonremovableSalesQuotation', 'U_DataRic', 'U_Tipo',
]
ODLN_DB = [
    'DocNum', 'DocType', 'Handwrtten', 'Printed', 'DocDate', 'DocDueDate', 'CardCode', 'CardName',
    'Address', 'NumAtCard', 'DocCur', 'DocRate', 'DocTotal', 'Ref1', 'Ref2', 'Comments',
    'JrnlMemo', 'GroupNum', 'DocTime', 'SlpCode', 'TrnspCode', 'Confirmed', 'ImportEnt',
    'SummryType', 'CntctCode', 'ShowSCN', 'Series', 'TaxDate', 'PartSupply', 'ObjType',
    'ShipToCode', 'Indicator', 'LicTradNum', 'DiscPrcnt', 'PaymentRef', 'DocTotalFC', 'Form1099',
    'Box1099', 'RevisionPo', 'ReqDate', 'CancelDate', 'BlockDunn', 'Pick', 'PeyMethod', 'PayBlock',
    'PayBlckRef', 'CntrlBnk', 'MaxDscn', 'Project', 'FromDate', 'ToDate', 'UpdInvnt', 'Rounding',
    'CorrExt', 'CorrInv', 'DeferrTax', 'LetterNum', 'AgentCode', 'Installmnt', 'VATFirst',
    'VatDate', 'OwnerCode', 'FolioPref', 'FolioNum', 'DocSubType', 'BPChCode', 'BPChCntc',
    'Address2', 'PayToCode', 'ManualNum', 'UseShpdGd', 'IsPaytoBnk', 'BnkCntry', 'BankCode',
    'BnkAccount', 'BnkBranch', 'BPLId', 'DpmPrcnt', 'isIns', 'LangCode', 'TrackNo', 'PickRmrk',
    'ClsDate', 'SeqCode', 'Serial', 'SeriesStr', 'SubStr', 'Model', 'UseCorrVat', 'DpmAmnt',
    'DpmPrcnt', 'Posted', 'DpmAmntSC', 'DpmAmntFC', 'VatPercent', 'SrvGpPrcnt', 'Header', 'Footer',
    'RoundDif', 'CtlAccount', 'InsurOp347', 'IgnRelDoc', 'U_DataRic', 'U_Tipo',
]

DLN1_SDK = [
    'ParentKey', 'LineNum', 'ItemCode', 'ItemDescription', 'Quantity', 'ShipDate', 'Price',
    'PriceAfterVAT', 'Currency', 'Rate', 'DiscountPercent', 'VendorNum', 'SerialNum',
    'WarehouseCode', 'SalesPersonCode', 'CommisionPercent', 'TreeType', 'AccountCode',
    'UseBaseUnits', 'SupplierCatNum', 'CostingCode', 'ProjectCode', 'BarCode', 'VatGroup',
    'Height1', 'Hight1Unit', 'Height2', 'Height2Unit', 'Lengh1', 'Lengh1Unit', 'Lengh2',
    'Lengh2Unit', 'Weight1', 'Weight1Unit', 'Weight2', 'Weight2Unit', 'Factor1', 'Factor2',
    'Factor3', 'Factor4', 'BaseType', 'BaseEntry', 'BaseLine', 'Volume', 'VolumeUnit', 'Width1',
    'Width1Unit', 'Width2', 'Width2Unit', 'Address', 'TaxCode', 'TaxType', 'TaxLiable',
    'BackOrder', 'FreeText', 'ShippingMethod', 'CorrectionInvoiceItem', 'CorrInvAmountToStock',
    'CorrInvAmountToDiffAcct', 'WTLiable', 'DeferredTax', 'MeasureUnit', 'UnitsOfMeasurment',
    'LineTotal', 'TaxPercentagePerRow', 'TaxTotal', 'ConsumerSalesForecast', 'ExciseAmount',
    'CountryOrg', 'SWW', 'TransactionType', 'DistributeExpense', 'ShipToCode', 'RowTotalFC',
    'CFOPCode', 'CSTCode', 'Usage', 'TaxOnly', 'UnitPrice', 'LineStatus', 'LineType',
    'COGSCostingCode', 'COGSAccountCode', 'ChangeAssemlyBoMWarehouse', 'GrossBuyPrice',
    'GrossBase', 'GrossProfitTotalBasePrice', 'CostingCode2', 'CostingCode3', 'CostingCode4',
    'CostingCode5', 'ItemDetails', 'LocationCode', 'ActualDeliveryDate', 'ExLineNo',
    'RequiredDate', 'RequiredQuantity', 'COGSCostingCode2', 'COGSCostingCode3', 'COGSCostingCode4',
    'COGSCostingCode5', 'WithoutInventoryMovement', 'AgrementNo', 'AgreementRowNumber',
    'ShipToDescription', 'U_CDC', 'U_Location', 'U_IDScheda', 'U_PO', 'U_PartNumber',
]
DLN1_DB = [
    'DocNum', 'LineNum', 'ItemCode', 'Dscription', 'Quantity', 'ShipDate', 'Price', 'PriceAfVAT',
    'Currency', 'Rate', 'DiscPrcnt', 'VendorNum', 'SerialNum', 'WhsCode', 'SlpCode', 'Commission',
    'TreeType', 'AcctCode', 'UseBaseUn', 'SubCatNum', 'OcrCode', 'Project', 'CodeBars', 'VatGroup',
    'Height1', 'Hght1Unit', 'Height2', 'Hght2Unit', 'Length1', 'Len1Unit', 'length2', 'Len2Unit',
    'Weight1', 'Wght1Unit', 'Weight2', 'Wght2Unit', 'Factor1', 'Factor2', 'Factor3', 'Factor4',
    'BaseType', 'BaseEntry', 'BaseLine', 'Volume', 'VolUnit', 'Width1', 'Wdth1Unit', 'Width2',
    'Wdth2Unit', 'Address', 'TaxCode', 'TaxType', 'TaxStatus', 'BackOrdr', 'FreeTxt', 'TrnsCode',
    'CEECFlag', 'ToStock', 'ToDiff', 'WtLiable', 'DeferrTax', 'unitMsr', 'NumPerMsr', 'LineTotal',
    'VatPrcnt', 'VatSum', 'ConsumeFCT', 'ExciseAmt', 'CountryOrg', 'SWW', 'TranType', 'DistribExp',
    'ShipToCode', 'TotalFrgn', 'CFOPCode', 'CSTCode', 'Usage', 'TaxOnly', 'PriceBefDi',
    'LineStatus', 'LineType', 'CogsOcrCod', 'CogsAcct', 'ChgAsmBoMW', 'GrossBuyPr', 'GrossBase',
    'GPTtlBasPr', 'OcrCode2', 'OcrCode3', 'OcrCode4', 'OcrCode5', 'Text', 'LocCode', 'ActDelDate',
    'ExLineNo', 'PQTReqDate', 'PQTReqQty', 'CogsOcrCo2', 'CogsOcrCo3', 'CogsOcrCo4', 'CogsOcrCo5',
    'NoInvtryMv', 'AgrNo', 'AgrLnNum', 'ShipToDesc', 'U_CDC', 'U_Location', 'U_IDScheda', 'U_PO',
    'U_PartNUmber',
]

SRNT_SDK = [
    'ParentKey', 'LineNum', 'ManufacturerSerialNumber', 'InternalSerialNumber', 'ExpiryDate',
    'ManufactureDate', 'ReceptionDate', 'WarrantyStart', 'WarrantyEnd', 'Location', 'Notes',
    'BatchID', 'SystemSerialNumber', 'BaseLineNumber', 'U_Stato',
]
SRNT_DB = [
    'DocNum', 'LineNum', 'MnfSerial', 'DistNumber', 'ExpDate', 'MnfDate', 'InDate', 'GrntStart',
    'GrntExp', 'Location', 'Notes', 'LotNumber', 'SysNumber', 'DocLineNum', 'U_Stato',
]

BTNT_SDK = [
    'ParentKey', 'LineNum', 'BatchNumber', 'ManufacturerSerialNumber', 'InternalSerialNumber',
    'ExpiryDate', 'ManufacturingDate', 'AddmisionDate', 'Location', 'Notes', 'Quantity',
    'BaseLineNumber', 'U_Stato',
]
BTNT_DB = [
    'DocNum', 'LineNum', 'DistNumber', 'MnfSerial', 'LotNumber', 'ExpDate', 'MnfDate', 'InDate',
    'Location', 'Notes', 'Quantity', 'DocLineNum', 'U_Stato',
]

BINLOCATION_SDK = [
    'ParentKey', 'LineNum', 'BinAbsEntry', 'Quantity', 'AllowNegativeQuantity', 'BaseLineNumber',
    'SerialAndBatchNumbersBaseLine',
]
BINLOCATION_DB = [
    'DocNum', 'LineNum', 'BinAbsEntry', 'Quantity', 'AllowNegativeQuantity', 'DocLineNum',
    'SerialAndBatchNumbersBaseLine',
]

# ============================================================
# CONFIG DI DEFAULT (scritto su file al primo avvio)
# ============================================================
DEFAULT_CONFIG = OrderedDict([
    ("foglio_input", "Righe"),
    ("colonne_form", OrderedDict([
        ("plant", "Plant"),
        ("storage_location", "Storage Location"),
        ("sap_code", "Sap Code"),
        ("wms_code", "Wms Code"),
        ("part_number", "Part Number"),
        ("profilo", "Profilo"),
        ("qta", "qta"),
        ("seriale_lotto", "Seriale/Lotto"),
        ("riscontro", "Riscontro Seriale/Lotto"),
        ("esito", "Esito"),
        ("bin", "Bin"),
        ("bin_abs_entry", "NumeroInterno"),
        ("numero_doc", "Numero Odr/ODP"),
        ("impresa", "Impresa"),
        ("scheda", "Scheda"),
        ("operatore", "Operatore"),
        ("data", "Data Elaborazione"),
        ("ddt", "DDT"),
    ])),
    # Valori fissi di testata (chiave = nome SDK colonna ODLN)
    ("testata", OrderedDict([
        ("DocType", "dDocument_Items"),
        ("CardCode", "F000263"),
        ("CardName", "FASTWEB SPA"),
        ("TransportationCode", "1"),
        ("Series", "275"),
        ("Project", "NTD"),
        ("U_Tipo", "ODR"),
    ])),
    # Valori fissi di riga (chiave = nome SDK colonna DLN1)
    ("righe", OrderedDict([
        ("Price", "0"),
        ("ProjectCode", "NTD"),
    ])),
    # Valore colonna Profilo -> gestione articolo
    ("profili", OrderedDict([
        ("serializzato", "SERIALE"),
        ("qty", "LOTTO"),
    ])),
    ("esiti_validi", ["OK"]),
    ("verifica_riscontro", True),
    # Magazzino: ricavato dal codice Bin (primi N segmenti) oppure fisso
    ("magazzino", OrderedDict([
        ("da_bin", True),
        ("separatore_bin", "-"),
        ("segmenti_bin", 2),
        ("default", "CE14-STK"),
    ])),
    # Plant -> U_CDC
    ("decodifica_cdc", OrderedDict([
        ("FLM", "1"), ("FPX", "2"), ("GCH", "3"), ("IWT-PASSIVE", "4"), ("IWT-SPARE", "5"),
        ("ZAS", "6"), ("IT2N", "7"), ("IT2V", "8"), ("IT7N", "9"), ("IT7V", "10"),
        ("IT4N", "11"), ("IT4V", "12"), ("IT6N", "13"), ("IT6V", "14"), ("ITA", "15"),
        ("AGL", "16"), ("ATSBO", "17"), ("ATSSF", "18"),
    ])),
    # Storage Location -> U_Stato (seriali e lotti)
    ("decodifica_stato", OrderedDict([
        ("NUOVO", "01"), ("USATO", "02"), ("ROTTAME", "03"), ("GUASTO", "04"),
        ("IN ATTESA ISTRUZIONI", "05"), ("SCRAP AREA 1", "06"), ("SCRAP AREA 2", "07"),
        ("SCRAP AREA 3", "08"), ("SCRAP AREA 4", "09"), ("SCRAP AREA 5", "10"),
        ("SCRAP AREA 6", "11"), ("SCRAP AREA 7", "12"), ("SCRAP AREA 8", "13"),
        ("SCRAP AREA 9", "14"), ("SCRAP AREA 10", "15"), ("TO TEST", "16"),
        ("SPECIAL STOCK1", "17"), ("SPECIAL STOCK2", "18"),
    ])),
    ("encoding_output", "cp1252"),
    # Rinomina il form in <nome>_Lavorato se tutte le sue righe sono state generate
    ("rinomina_lavorati", True),
])


def load_config():
    """Carica il config; se manca lo crea. Le chiavi mancanti vengono prese dal default."""
    if not os.path.exists(CONFIG_PATH):
        save_config(DEFAULT_CONFIG)
        return json.loads(json.dumps(DEFAULT_CONFIG), object_pairs_hook=OrderedDict)
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f, object_pairs_hook=OrderedDict)
    for k, v in DEFAULT_CONFIG.items():
        if k not in cfg:
            cfg[k] = v
        elif isinstance(v, dict) and k == "colonne_form":
            for kk, vv in v.items():
                cfg[k].setdefault(kk, vv)
    return cfg


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ============================================================
# NORMALIZZAZIONE VALORI
# ============================================================
def norm_str(v):
    """Valore cella -> stringa pulita. Interi senza '.0', zeri iniziali preservati se già testo."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


def parse_qty(v):
    """Ritorna (testo_dtw, valore_float) oppure (None, None) se non valida."""
    s = norm_str(v).replace(",", ".")
    if s == "":
        return None, None
    try:
        q = float(s)
    except ValueError:
        return None, None
    txt = str(int(q)) if q.is_integer() else str(q)
    return txt, q


def parse_date_smart(v):
    """Data -> 'yyyymmdd'. Accetta datetime, yyyy-mm-dd, dd/mm/yyyy (default italiano), yyyymmdd."""
    if v is None or v == "":
        return None
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y%m%d")
    s = norm_str(v).split(" ")[0].split("T")[0]
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%Y%m%d", "%Y/%m/%d", "%d/%m/%y"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y%m%d")
        except ValueError:
            continue
    return None

# ============================================================
# LETTURA FORM
# ============================================================
def read_form(path, cfg, log):
    """Legge il form e ritorna (intestazioni_originali, lista righe).
    Ogni riga: {'_file', '_riga', '_raw': {colonna: valore}, campo_logico: valore}"""
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    foglio = cfg.get("foglio_input") or ""
    if foglio in wb.sheetnames:
        ws = wb[foglio]
    else:
        ws = wb.worksheets[0]
        if foglio:
            log(f"  Foglio '{foglio}' non trovato, uso '{ws.title}'")

    rows_iter = ws.iter_rows(values_only=True)
    try:
        header = [norm_str(h) for h in next(rows_iter)]
    except StopIteration:
        wb.close()
        return [], []

    idx = {h.lower(): i for i, h in enumerate(header) if h}
    mappa = cfg["colonne_form"]
    obbligatorie = ["numero_doc", "wms_code", "qta", "profilo", "seriale_lotto", "bin_abs_entry", "ddt"]
    pos = {}
    mancanti = []
    for campo, nome_col in mappa.items():
        i = idx.get(str(nome_col).strip().lower())
        if i is None:
            if campo in obbligatorie:
                mancanti.append(nome_col)
            else:
                log(f"  Attenzione: colonna '{nome_col}' non trovata, il campo resterà vuoto")
        pos[campo] = i
    if mancanti:
        wb.close()
        raise ValueError(f"Colonne obbligatorie mancanti in {os.path.basename(path)}: {', '.join(mancanti)}")

    righe = []
    for n, r in enumerate(rows_iter, start=2):
        if r is None or all(v in (None, "") for v in r):
            continue
        rec = {"_file": os.path.basename(path), "_path": path, "_riga": n,
               "_raw": OrderedDict((header[i], r[i] if i < len(r) else None) for i in range(len(header)) if header[i])}
        for campo, i in pos.items():
            rec[campo] = r[i] if (i is not None and i < len(r)) else None
        righe.append(rec)
    wb.close()
    return header, righe


# ============================================================
# ELABORAZIONE
# ============================================================
def warehouse_da_bin(bin_code, cfg):
    m = cfg["magazzino"]
    if not m.get("da_bin"):
        return m.get("default", "")
    b = norm_str(bin_code)
    if not b:
        return ""
    sep = m.get("separatore_bin", "-")
    n = int(m.get("segmenti_bin", 2))
    parti = b.split(sep)
    if len(parti) < n:
        return ""
    return sep.join(parti[:n])


def valida_riga(rec, cfg):
    """Normalizza la riga e ritorna la lista dei motivi di anomalia (vuota = ok)."""
    motivi = []
    rec["doc"] = norm_str(rec.get("numero_doc"))
    rec["item"] = norm_str(rec.get("wms_code"))
    rec["sap_code"] = norm_str(rec.get("sap_code"))
    rec["part_number"] = norm_str(rec.get("part_number"))
    rec["seriale"] = norm_str(rec.get("seriale_lotto"))
    rec["impresa_n"] = norm_str(rec.get("impresa"))
    rec["operatore_n"] = norm_str(rec.get("operatore"))
    rec["scheda_n"] = norm_str(rec.get("scheda"))
    rec["ddt_n"] = norm_str(rec.get("ddt"))
    rec["bin_entry"] = norm_str(rec.get("bin_abs_entry"))

    if not rec["doc"]:
        motivi.append("Numero documento mancante")
    if not rec["item"]:
        motivi.append("Wms Code mancante")

    qtxt, q = parse_qty(rec.get("qta"))
    rec["qta_txt"], rec["qta_val"] = qtxt, q
    if q is None or q <= 0:
        motivi.append("Quantità non valida")

    profilo = norm_str(rec.get("profilo")).lower()
    gestione = {k.lower(): v for k, v in cfg["profili"].items()}.get(profilo)
    rec["gestione"] = gestione
    if gestione is None:
        motivi.append(f"Profilo non gestito ({norm_str(rec.get('profilo'))})")
    if not rec["seriale"]:
        motivi.append("Seriale/Lotto mancante")
    if gestione == "SERIALE" and q is not None and q != 1:
        motivi.append("Articolo serializzato con quantità diversa da 1")

    esiti = [e.upper() for e in cfg.get("esiti_validi", ["OK"])]
    if norm_str(rec.get("esito")).upper() not in esiti:
        motivi.append(f"Esito non valido ({norm_str(rec.get('esito')) or 'vuoto'})")
    if cfg.get("verifica_riscontro", True) and norm_str(rec.get("riscontro")) != rec["seriale"]:
        motivi.append("Riscontro diverso da Seriale/Lotto")

    if not rec["bin_entry"].isdigit():
        motivi.append("NumeroInterno (BinAbsEntry) mancante o non numerico")
    rec["whs"] = warehouse_da_bin(rec.get("bin"), cfg)
    if not rec["whs"]:
        motivi.append("Magazzino non ricavabile dal Bin")

    cdc = cfg["decodifica_cdc"].get(norm_str(rec.get("plant")).upper())
    rec["cdc"] = cdc
    if cdc is None:
        motivi.append(f"Plant non in decodifica CDC ({norm_str(rec.get('plant')) or 'vuoto'})")
    stato = cfg["decodifica_stato"].get(norm_str(rec.get("storage_location")).upper())
    rec["stato"] = stato
    if stato is None:
        motivi.append(f"Storage Location non in decodifica Stato ({norm_str(rec.get('storage_location')) or 'vuoto'})")

    rec["data_n"] = parse_date_smart(rec.get("data"))
    if rec["data_n"] is None:
        motivi.append(f"Data non valida ({norm_str(rec.get('data')) or 'vuota'})")
    return motivi


def elabora(file_list, cfg, log):
    """Ritorna (docs_validi: OrderedDict doc -> righe, anomalie: lista (rec, motivo))."""
    tutte = []
    for p in file_list:
        log(f"Lettura: {os.path.basename(p)}")
        _, righe = read_form(p, cfg, log)
        log(f"  {len(righe)} righe")
        tutte.extend(righe)

    docs = OrderedDict()
    motivi_riga = {}
    for rec in tutte:
        motivi_riga[id(rec)] = valida_riga(rec, cfg)
        docs.setdefault(rec["doc"], []).append(rec)

    validi = OrderedDict()
    anomalie = []
    for doc, righe in docs.items():
        motivi_doc = []
        file_doc = {r["_file"] for r in righe}
        if len(file_doc) > 1:
            motivi_doc.append("Documento presente in più file: " + ", ".join(sorted(file_doc)))
        if len({r["data_n"] for r in righe}) > 1:
            motivi_doc.append("Date diverse nello stesso documento")
        if len({r["impresa_n"] for r in righe}) > 1:
            motivi_doc.append("Impresa diversa nello stesso documento")
        if not righe[0]["impresa_n"]:
            motivi_doc.append("Impresa (ShipToCode) mancante")
        if len({r["ddt_n"] for r in righe}) > 1:
            motivi_doc.append("DDT diverso nello stesso documento")
        if not righe[0]["ddt_n"]:
            motivi_doc.append("DDT (NumAtCard) mancante")
        visti = defaultdict(int)
        for r in righe:
            if r["gestione"] == "SERIALE":
                visti[r["seriale"]] += 1
        dup = [s for s, c in visti.items() if c > 1]
        if dup:
            motivi_doc.append("Seriali duplicati nel documento: " + ", ".join(dup))

        ha_anomalie = bool(motivi_doc) or any(motivi_riga[id(r)] for r in righe)
        if ha_anomalie:
            for r in righe:
                m = motivi_riga[id(r)] + motivi_doc
                if not m:
                    m = ["Documento bloccato da anomalie su altre righe"]
                anomalie.append((r, "; ".join(m)))
            log(f"  Documento {doc or '(senza numero)'}: ANOMALIE, spostato nel file anomalie")
        else:
            validi[doc] = righe

    # Seriali ripetuti tra documenti diversi: solo avviso
    ser_doc = defaultdict(set)
    for doc, righe in validi.items():
        for r in righe:
            if r["gestione"] == "SERIALE":
                ser_doc[r["seriale"]].add(doc)
    for s, ds in ser_doc.items():
        if len(ds) > 1:
            log(f"  Avviso: seriale {s} presente in più documenti ({', '.join(sorted(ds))})")
    return validi, anomalie


# ============================================================
# COSTRUZIONE TRACCIATI
# ============================================================
def costruisci_tracciati(validi, cfg):
    odln, dln1, srnt, btnt, binl = [], [], [], [], []
    for doc, righe in validi.items():
        r0 = righe[0]
        t = {k: str(v) for k, v in cfg["testata"].items()}
        t.update({
            "DocNum": doc,
            "NumAtCard": r0["ddt_n"],
            "DocDate": r0["data_n"],
            "DocDueDate": r0["data_n"],
            "TaxDate": r0["data_n"],
            "U_DataRic": r0["data_n"],
            "ShipToCode": r0["impresa_n"],
        })
        odln.append(t)

        n_ser = n_lot = n_bin = 0
        for line, r in enumerate(righe):
            d = {k: str(v) for k, v in cfg["righe"].items()}
            d.update({
                "ParentKey": doc,
                "LineNum": str(line),
                "ItemCode": r["item"],
                "Quantity": r["qta_txt"],
                "WarehouseCode": r["whs"],
                "SupplierCatNum": r["sap_code"],
                "FreeText": r["operatore_n"],
                "U_CDC": str(r["cdc"]),
                "U_IDScheda": r["scheda_n"],
                "U_PO": doc,
                "U_PartNumber": r["part_number"],
            })
            dln1.append(d)

            if r["gestione"] == "SERIALE":
                srnt.append({
                    "ParentKey": doc, "LineNum": str(n_ser),
                    "ManufacturerSerialNumber": r["seriale"],
                    "InternalSerialNumber": r["seriale"],
                    "BaseLineNumber": str(line),
                    "U_Stato": r["stato"],
                })
                n_ser += 1
            else:
                btnt.append({
                    "ParentKey": doc, "LineNum": str(n_lot),
                    "BatchNumber": r["seriale"],
                    "ManufacturerSerialNumber": r["seriale"],
                    "InternalSerialNumber": r["seriale"],
                    "Quantity": r["qta_txt"],
                    "BaseLineNumber": str(line),
                    "U_Stato": r["stato"],
                })
                n_lot += 1

            binl.append({
                "ParentKey": doc, "LineNum": str(n_bin),
                "BinAbsEntry": r["bin_entry"],
                "Quantity": r["qta_txt"],
                "BaseLineNumber": str(line),
                "SerialAndBatchNumbersBaseLine": "0",
            })
            n_bin += 1
    return OrderedDict([
        ("ODLN", (ODLN_SDK, ODLN_DB, odln)),
        ("DLN1", (DLN1_SDK, DLN1_DB, dln1)),
        ("SRNT", (SRNT_SDK, SRNT_DB, srnt)),
        ("BTNT", (BTNT_SDK, BTNT_DB, btnt)),
        ("BINLOCATION", (BINLOCATION_SDK, BINLOCATION_DB, binl)),
    ])


def verifica_chiavi_config(cfg, log):
    for k in cfg["testata"]:
        if k not in ODLN_SDK:
            log(f"Attenzione: '{k}' in config.testata non esiste nel tracciato ODLN, ignorato")
    for k in cfg["righe"]:
        if k not in DLN1_SDK:
            log(f"Attenzione: '{k}' in config.righe non esiste nel tracciato DLN1, ignorato")


# ============================================================
# SCRITTURA FILE
# ============================================================
def scrivi_dtw(path, sdk, db, righe, encoding):
    """TXT tab-separato, CRLF, doppia intestazione (formato validato in DTW)."""
    with open(path, "w", encoding=encoding, errors="replace", newline="") as f:
        f.write("\t".join(sdk) + "\r\n")
        f.write("\t".join(db) + "\r\n")
        for r in righe:
            vals = [str(r.get(c, "") or "").replace("\t", " ").replace("\r", " ").replace("\n", " ")
                    for c in sdk]
            f.write("\t".join(vals) + "\r\n")


def scrivi_anomalie(path, anomalie):
    """Excel con le colonne originali del form + File, Riga, Motivo (ricaricabile dopo la correzione)."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Righe"
    colonne = []
    for rec, _ in anomalie:
        for c in rec["_raw"]:
            if c not in colonne:
                colonne.append(c)
    intest = colonne + ["File Origine", "Riga Origine", "Motivo_Errore"]
    ws.append(intest)
    for c in ws[1]:
        c.font = Font(bold=True)
    rosso = PatternFill("solid", fgColor="FFF2CC")
    for rec, motivo in anomalie:
        ws.append([rec["_raw"].get(c) for c in colonne] + [rec["_file"], rec["_riga"], motivo])
        ws.cell(ws.max_row, len(intest)).fill = rosso
    for i, h in enumerate(intest, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = max(12, min(60, len(str(h)) + 4))
    ws.column_dimensions[openpyxl.utils.get_column_letter(len(intest))].width = 80
    wb.save(path)


def rinomina_lavorati(file_list, validi, anomalie, stamp, log):
    """Rinomina in <nome>_Lavorato.<ext> i form con tutte le righe finite nei DTW."""
    ko = {r["_path"] for r, _ in anomalie}
    ok = {r["_path"] for righe in validi.values() for r in righe}
    for p in file_list:
        nome = os.path.basename(p)
        base, ext = os.path.splitext(p)
        if p in ko:
            log(f"  {nome}: non rinominato, contiene righe in anomalia")
            continue
        if p not in ok:
            log(f"  {nome}: non rinominato, nessuna riga elaborata")
            continue
        if base.endswith("_Lavorato"):
            log(f"  Avviso: {nome} era già marcato come lavorato, non rinominato")
            continue
        nuovo = base + "_Lavorato" + ext
        if os.path.exists(nuovo):
            nuovo = f"{base}_Lavorato_{stamp}{ext}"
        try:
            os.rename(p, nuovo)
            log(f"  {nome} -> {os.path.basename(nuovo)}")
        except OSError as e:
            log(f"  {nome}: impossibile rinominare ({e}). Il file è aperto in Excel?")


def genera(file_list, out_base, cfg, log, progress=None):
    """Esegue tutto il flusso. Ritorna la cartella di output."""
    prog = progress or (lambda v: None)
    verifica_chiavi_config(cfg, log)
    prog(10)
    validi, anomalie = elabora(file_list, cfg, log)
    prog(50)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.normpath(os.path.join(out_base, f"EntrataMerci_{stamp}"))
    os.makedirs(out_dir, exist_ok=True)

    if validi:
        tracciati = costruisci_tracciati(validi, cfg)
        for nome, (sdk, db, righe) in tracciati.items():
            scrivi_dtw(os.path.join(out_dir, f"{nome}.txt"), sdk, db, righe, cfg.get("encoding_output", "cp1252"))
            log(f"Scritto {nome}.txt ({len(righe)} righe)")
        log(f"Documenti generati: {len(validi)} -> {', '.join(validi.keys())}")
        if cfg.get("rinomina_lavorati", True):
            rinomina_lavorati(file_list, validi, anomalie, stamp, log)
        prog(85)
    else:
        log("Nessun documento valido: file DTW non generati")

    if anomalie:
        p = os.path.join(out_dir, f"Anomalie_Da_Definire_{stamp}.xlsx")
        scrivi_anomalie(p, anomalie)
        log(f"Righe in anomalia: {len(anomalie)} -> {os.path.basename(p)}")
    return out_dir

# ============================================================
# EDITOR CONFIGURAZIONE (stesso stile del Generatore ODP NTD)
# ============================================================
def show_config_editor():
    try:
        config = load_config()
    except Exception as e:
        messagebox.showerror("Errore", f"Errore nel file {CONFIG_NAME}:\n{e}")
        return

    win = tk.Toplevel(root)
    win.title("Editor Configurazione")
    win.geometry("460x620")

    # Contenitore scrollabile (le decodifiche sono lunghe)
    canvas = tk.Canvas(win, highlightthickness=0)
    vsb = tk.Scrollbar(win, orient="vertical", command=canvas.yview)
    body = tk.Frame(canvas)
    body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=body, anchor="nw")
    canvas.configure(yscrollcommand=vsb.set)
    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    def _wheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    win.bind("<MouseWheel>", _wheel)

    entries = {}
    row = 0

    def titolo(testo):
        nonlocal row
        tk.Label(body, text=testo, font=("Segoe UI", 10, "bold")).grid(
            row=row, column=0, columnspan=2, pady=(15 if row else 10, 5), sticky="w", padx=5)
        row += 1

    def sezione(testo, chiave):
        nonlocal row
        titolo(testo)
        for key, val in config.get(chiave, {}).items():
            tk.Label(body, text=key).grid(row=row, column=0, sticky="w", padx=5, pady=2)
            entry = tk.Entry(body, width=30)
            entry.grid(row=row, column=1, padx=5, pady=2)
            entry.insert(0, str(val))
            entries[(chiave, key)] = entry
            row += 1

    sezione("Impostazioni ODLN Defaults", "testata")
    sezione("Impostazioni DLN1 Defaults", "righe")

    # Sezione magazzino
    titolo("Magazzino")
    mag = config.get("magazzino", {})
    var_da_bin = tk.BooleanVar(value=bool(mag.get("da_bin", True)))
    tk.Checkbutton(body, text="Ricava magazzino dal Bin", variable=var_da_bin).grid(
        row=row, column=0, columnspan=2, sticky="w", padx=5)
    row += 1
    tk.Label(body, text="Segmenti Bin").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    seg_entry = tk.Entry(body, width=30)
    seg_entry.grid(row=row, column=1, padx=5, pady=2)
    seg_entry.insert(0, str(mag.get("segmenti_bin", 2)))
    row += 1
    tk.Label(body, text="Warehouse di default").grid(row=row, column=0, sticky="w", padx=5, pady=2)
    whs_entry = tk.Entry(body, width=30)
    whs_entry.grid(row=row, column=1, padx=5, pady=2)
    whs_entry.insert(0, str(mag.get("default", "")))
    row += 1

    # Sezioni decodifica: righe modificabili + aggiunta nuove righe
    def sezione_decodifica(testo, chiave, label_key, label_val):
        nonlocal row
        titolo(testo)
        sub = tk.Frame(body)
        sub.grid(row=row, column=0, columnspan=2, sticky="w", padx=5)
        row += 1
        tk.Label(sub, text=label_key, font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 5))
        tk.Label(sub, text=label_val, font=("Segoe UI", 9, "bold")).grid(row=0, column=1, sticky="w")
        coppie = []

        def aggiungi(k="", v=""):
            r = len(coppie) + 1
            ek = tk.Entry(sub, width=30)
            ek.grid(row=r, column=0, padx=(0, 5), pady=2)
            ek.insert(0, k)
            ev = tk.Entry(sub, width=12)
            ev.grid(row=r, column=1, pady=2)
            ev.insert(0, v)
            coppie.append((ek, ev))

        for k, v in config.get(chiave, {}).items():
            aggiungi(str(k), str(v))
        tk.Button(body, text="+ Aggiungi riga", relief="flat", cursor="hand2", fg="#3498db",
                  command=aggiungi).grid(row=row, column=0, sticky="w", padx=5)
        row += 1
        return coppie

    cdc_rows = sezione_decodifica("Decodifica CDC (Plant -> U_CDC)", "decodifica_cdc", "Plant", "CDC")
    stato_rows = sezione_decodifica("Decodifica Stato (Storage Location -> U_Stato)", "decodifica_stato",
                                    "Storage Location", "Codice")
    tk.Label(body, text="Per eliminare una riga svuota il primo campo.",
             font=("Segoe UI", 8), fg="#7f8c8d").grid(row=row, column=0, columnspan=2, pady=(5, 0), padx=5, sticky="w")
    row += 1

    def leggi_decodifica(coppie, nome):
        out = OrderedDict()
        for ek, ev in coppie:
            k, v = ek.get().strip().upper(), ev.get().strip()
            if not k:
                continue
            if not v:
                raise ValueError(f"{nome}: valore mancante per '{k}'")
            if k in out:
                raise ValueError(f"{nome}: '{k}' presente più volte")
            out[k] = v
        return out

    def save_and_close():
        try:
            seg = int(seg_entry.get().strip())
            cdc = leggi_decodifica(cdc_rows, "Decodifica CDC")
            stato = leggi_decodifica(stato_rows, "Decodifica Stato")
        except ValueError as e:
            msg = str(e) if "Decodifica" in str(e) else "Segmenti Bin deve essere un numero intero."
            messagebox.showerror("Errore", msg, parent=win)
            return
        for (chiave, key), entry in entries.items():
            config[chiave][key] = entry.get().strip()
        config["magazzino"]["da_bin"] = var_da_bin.get()
        config["magazzino"]["segmenti_bin"] = seg
        config["magazzino"]["default"] = whs_entry.get().strip()
        config["decodifica_cdc"] = cdc
        config["decodifica_stato"] = stato
        save_config(config)
        messagebox.showinfo("Salvato", "Configurazione aggiornata!", parent=win)
        win.destroy()

    tk.Button(body, text="Salva e Chiudi", command=save_and_close).grid(row=row, column=0, columnspan=2, pady=15)


# ========================
# Logger GUI + File
# ========================
class GUILogger:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.righe = []
        self.log_file = open(LOG_PATH, "a", encoding="utf-8")

    def __call__(self, msg):
        riga = f"{datetime.now().strftime('%H:%M:%S')}  {msg}"
        self.righe.append(riga)
        root.after(0, self._scrivi, riga + "\n")
        self.log_file.write(f"{datetime.now().strftime('%Y-%m-%d')} {riga}\n")
        self.log_file.flush()

    def _scrivi(self, testo):
        self.text_widget.insert(tk.END, testo)
        self.text_widget.see(tk.END)

    def close(self):
        try:
            self.log_file.close()
        except Exception:
            pass


# ========================
# GUI
# ========================
root = tk.Tk()
root.title("Generatore Entrata Merci NTD - ATS")
root.geometry("820x680")
root.resizable(False, False)
root.configure(bg="#f0f4f8")

style = ttk.Style()
style.theme_use('clam')

# Frame in alto per pulsante impostazioni
top_frame = tk.Frame(root, bg="#f0f4f8")
top_frame.pack(side="top", fill="x", padx=10, pady=5)

btn_settings = tk.Button(top_frame, text="⚙️", font=("Segoe UI", 14), bg="#f0f4f8", fg="#2c3e50",
                         relief="flat", cursor="hand2", command=show_config_editor)
btn_settings.pack(side="right")

tk.Label(root, text="GENERATORE ENTRATA MERCI NTD", font=("Segoe UI", 20, "bold"), bg="#f0f4f8", fg="#2c3e50").pack(pady=(25, 8))
tk.Label(root, text="Seleziona uno o più form di ricevimento .xlsx per generare i DTW", font=("Segoe UI", 10), bg="#f0f4f8", fg="#7f8c8d").pack(pady=(0, 20))

frame = tk.Frame(root, bg="#f0f4f8")
frame.pack(pady=10, padx=35, fill="both", expand=True)

TESTO_SCEGLI = "SCEGLI FORM RICEVIMENTO .xlsx"
btn_scegli = tk.Button(frame, text=TESTO_SCEGLI, font=("Segoe UI", 11, "bold"), width=40, height=2, bg="#3498db", fg="white", relief="flat", cursor="hand2")
btn_scegli.pack(pady=15)

lbl_file = tk.Label(frame, text="Nessun file selezionato", font=("Segoe UI", 10), bg="#f0f4f8", fg="#95a5a6", wraplength=720)
lbl_file.pack(pady=(5, 15))

progress = ttk.Progressbar(frame, mode='determinate', length=720)
progress.pack(pady=10)

log_frame = tk.Frame(frame, bg="white", relief="sunken", bd=1)
log_frame.pack(pady=15, fill="both", expand=True)

log_text = tk.Text(log_frame, height=18, font=("Consolas", 9), bg="#fdfdfd", fg="#2c3e50", wrap="word")
log_text.pack(side="left", fill="both", expand=True, padx=5, pady=5)
scrollbar = tk.Scrollbar(log_frame, command=log_text.yview)
scrollbar.pack(side="right", fill="y")
log_text.config(yscrollcommand=scrollbar.set)

footer = tk.Label(root, text=f"Output: {OUTPUT_FOLDER} | Config: {CONFIG_NAME} | Log: EM_NTD_Log.log", font=("Segoe UI", 8), bg="#f0f4f8", fg="#95a5a6")
footer.pack(side="bottom", pady=15)

file_paths = []


def set_progress(v):
    root.after(0, lambda: progress.configure(value=v))


def reset_scelta():
    btn_scegli.config(text=TESTO_SCEGLI, command=scegli_file, bg="#3498db", state="normal")


# ========================
# Elaborazione
# ========================
def avvia_elaborazione():
    global file_paths
    if not file_paths:
        messagebox.showerror("Errore", "Seleziona almeno un file!")
        return
    try:
        cfg = load_config()
    except Exception as e:
        messagebox.showerror("Errore", f"Errore nel file {CONFIG_NAME}:\n{e}")
        return

    log_text.delete(1.0, tk.END)
    logger = GUILogger(log_text)
    btn_scegli.config(state="disabled")
    files = list(file_paths)

    def run():
        global file_paths
        try:
            set_progress(0)
            os.makedirs(OUTPUT_FOLDER, exist_ok=True)
            logger("=" * 60)
            logger("Avvio elaborazione")
            logger(f"Config: {CONFIG_PATH}")
            out_dir = genera(files, OUTPUT_FOLDER, cfg, logger, set_progress)
            logger(f"Output: {out_dir}")
            with open(os.path.join(out_dir, "log.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(logger.righe) + "\n")
            set_progress(100)
            anomalie = any(n.startswith("Anomalie_") for n in os.listdir(out_dir))
            msg = f"Elaborazione terminata!\nFile in:\n{out_dir}"
            if anomalie:
                msg += "\n\nAttenzione: trovate anomalie, controllare il file Anomalie_Da_Definire."
            root.after(0, lambda: messagebox.showinfo("Completato", msg))
        except Exception as e:
            err = str(e)
            logger(f"ERRORE: {err}")
            logger(traceback.format_exc())
            root.after(0, lambda: messagebox.showerror("Errore", err))
        finally:
            logger.close()
            file_paths = []
            root.after(0, lambda: lbl_file.config(text="Nessun file selezionato", fg="#95a5a6"))
            root.after(0, reset_scelta)

    Thread(target=run, daemon=True).start()


def scegli_file():
    global file_paths
    files = filedialog.askopenfilenames(
        title="Seleziona uno o più form di ricevimento",
        filetypes=[("File Excel", "*.xlsx *.XLSX *.xlsm *.XLSM"), ("Tutti i file", "*.*")]
    )
    if files:
        file_paths = list(files)
        nomi = ", ".join(os.path.basename(f) for f in file_paths)
        etichetta = "File" if len(file_paths) == 1 else f"File ({len(file_paths)})"
        lbl_file.config(text=f"{etichetta}: {nomi}", fg="#27ae60")
        btn_scegli.config(text="AVVIA ELABORAZIONE", command=avvia_elaborazione, bg="#27ae60")


btn_scegli.config(command=scegli_file)

if __name__ == "__main__":
    load_config()  # crea il config al primo avvio
    root.mainloop()
