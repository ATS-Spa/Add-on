
# Generatore RMA Ritorno in Giacenza - ATS.py
import os
import sys
import gzip
import shutil
import pandas as pd
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime, timedelta
from threading import Thread
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import logging
import locale

try:
    locale.setlocale(locale.LC_TIME, 'it_IT.UTF-8')
except:
    pass

# ========================
# Cartella base
# ========================
if getattr(sys, "frozen", False):
    base_path = os.path.dirname(sys.executable)
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

log_path = os.path.join(base_path, "RMA_RitornoGiacenza_Log.txt")
db_path = os.path.join(base_path, "Database_Generatore.db")
output_folder = os.path.join(base_path, "DTW_RMA_RitornoGiacenza_Output")
os.makedirs(output_folder, exist_ok=True)

# ========================
# Logger GUI + File
# ========================
class GUILogger:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.log_file = open(log_path, "a", encoding="utf-8")
    def write(self, message):
        self.text_widget.insert(tk.END, message)
        self.text_widget.see(tk.END)
        self.log_file.write(message)
        self.log_file.flush()
    def flush(self): pass
# ========================
# COLONNE DTW COMPLETE (copiate dal tuo script originale)
# ========================
ordr_columns = [
    "DocNum","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode","CardName","Address","NumAtCard","DocCur","DocRate","DocTotal","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt","SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply",
    "ObjType","ShipToCode","Indicator","LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate","CancelDate",
    "BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn","Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref","FolioNum","DocSubType","BPChCode","BPChCntc",
    "Address2","PayToCode","ManualNumber","UseShpdGd","IsPaytoBnk","BnkCntry","BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode",
    "TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model","UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC",
    "VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount","InsurOp347","IgnRelDoc","U_Tipo"
]

rdr1_columns = [
    "ParentKey","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT","Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SubCatNum","OcrCode","Project","CodeBars","VatGroup","Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4","BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag","ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","ShipToCode","RowTotalFC","CFOPCode","CSTCode","Usage","TaxOnly","UnitPrice","LineStatus","LineType",
    "COGSCostingCode","COGSAccountCode","ChangeAssemlyBoMWarehouse","GrossBuyPrice","GrossBase","GrossProfitTotalBasePrice","CostingCode2","CostingCode3","CostingCode4","CostingCode5",
    "ItemDetails","LocationCode","ActualDeliveryDate","ExLineNo","RequiredDate","RequiredQuantity","COGSCostingCode2","COGSCostingCode3","COGSCostingCode4","COGSCostingCode5",
    "WithoutInventoryMovement","AgrementNo","AgreementRowNumber","ShipToDescription","U_PartNumber","U_CDC","U_IDScheda","U_Location","U_PO","U_Posizione","U_ReqDate","U_TargaSito",
    "U_Seriale"
]

ordr_header_sap = [
    "DocNum","DocType","Handwrtten","Printed","DocDate","DocDueDate","CardCode","CardName","Address","NumAtCard","DocCur","DocRate","DocTotal","Ref1","Ref2",
    "Comments","JrnlMemo","GroupNum","DocTime","SlpCode","TrnspCode","Confirmed","ImportEnt","SummryType","CntctCode","ShowSCN","Series","TaxDate","PartSupply",
    "ObjType","ShipToCode","Indicator","LicTradNum","DiscPrcnt","PaymentRef","DocTotalFC","Form1099","Box1099","RevisionPo","ReqDate","CancelDate",
    "BlockDunn","Pick","PeyMethod","PayBlock","PayBlckRef","CntrlBnk","MaxDscn","Project","FromDate","ToDate","UpdInvnt","Rounding","CorrExt","CorrInv",
    "DeferrTax","LetterNum","AgentCode","Installmnt","VATFirst","VatDate","OwnerCode","FolioPref","FolioNum","DocSubType","BPChCode","BPChCntc",
    "Address2","PayToCode","ManualNumber","UseShpdGd","IsPaytoBnk","BnkCntry","BankCode","BnkAccount","BnkBranch","BPLId","DpmPrcnt","isIns","LangCode",
    "TrackNo","PickRmrk","ClsDate","SeqCode","Serial","SeriesStr","SubStr","Model","UseCorrVat","DpmAmnt","DpmPrcnt","Posted","DpmAmntSC","DpmAmntFC",
    "VatPercent","SrvGpPrcnt","Header","Footer","RoundDif","CtlAccount","InsurOp347","IgnRelDoc","U_Tipo"
]

rdr1_header_sap = [
    "DocNum","LineNum","ItemCode","Dscription","Quantity","ShipDate","Price","PriceAfVAT","Currency","Rate","DiscPrcnt","VendorNum","SerialNum","WhsCode","SlpCode","Commission",
    "TreeType","AcctCode","UseBaseUn","SupplierCatNum","OcrCode","Project","CodeBars","VatGroup","Height1","Hght1Unit","Height2","Hght2Unit","Length1","Len1Unit","length2","Len2Unit",
    "Weight1","Wght1Unit","Weight2","Wght2Unit","Factor1","Factor2","Factor3","Factor4","BaseType","BaseEntry","BaseLine","Volume","VolUnit","Width1","Wdth1Unit","Width2","Wdth2Unit",
    "Address","TaxCode","TaxType","TaxStatus","BackOrdr","FreeTxt","TrnsCode","CEECFlag","ToStock","ToDiff","WtLiable","DeferrTax","unitMsr","NumPerMsr","LineTotal","VatPrcnt",
    "VatSum","ConsumeFCT","ExciseAmt","CountryOrg","SWW","TranType","DistribExp","ShipToCode","TotalFrgn","CFOPCode","CSTCode","Usage","TaxOnly","PriceBefDi","LineStatus","LineType",
    "CogsOcrCod","CogsAcct","ChgAsmBoMW","GrossBuyPr","GrossBase","GPTtlBasPr","OcrCode2","OcrCode3","OcrCode4","OcrCode5","Text","LocCode","ActDelDate","ExLineNo","PQTReqDate",
    "PQTReqQty","CogsOcrCo2","CogsOcrCo3","CogsOcrCo4","CogsOcrCo5","NoInvtryMv","AgrNo","AgrLnNum","ShipToDesc","U_PartNumber","U_CDC","U_IDScheda","U_Location","U_PO","U_Posizione",
    "U_ReqDate","U_TargaSito","U_Seriale"
]

# ========================
# GUI
# ========================
root = tk.Tk()
root.title("Generatore RMA - Ritorno in Giacenza (RMA.CSV opzionale)")
root.geometry("960x860")
root.resizable(False, False)
root.configure(bg="#f0f4f8")

style = ttk.Style()
style.theme_use('clam')

tk.Label(root, text="GENERATORE RMA RITORNO IN GIACENZA", font=("Segoe UI", 20, "bold"), bg="#f0f4f8", fg="#2c3e50").pack(pady=(25,8))
tk.Label(root, text="RMA.CSV = opzionale | FR.CSV + Report Articoli = obbligatori", font=("Segoe UI", 11), bg="#f0f4f8", fg="#e74c3c").pack(pady=(0,15))

frame = tk.Frame(root, bg="#f0f4f8")
frame.pack(pady=10, padx=35, fill="both", expand=True)

btn_rma = tk.Button(frame, text="1. RMA.CSV / RMA.CSV.GZ (OPZIONALE)", font=("Segoe UI", 10, "bold"), width=70, height=2, bg="#3498db", fg="white")
btn_rma.pack(pady=8)
lbl_rma = tk.Label(frame, text="Nessun file RMA selezionato", fg="#95a5a6", wraplength=850)
lbl_rma.pack()

btn_fr = tk.Button(frame, text="2. FR.CSV / FR.CSV.GZ (OBBLIGATORIO)", font=("Segoe UI", 10, "bold"), width=70, height=2, bg="#e74c3c", fg="white")
btn_fr.pack(pady=8)
lbl_fr = tk.Label(frame, text="Nessun file FR selezionato", fg="#95a5a6", wraplength=850)
lbl_fr.pack()

btn_xls = tk.Button(frame, text="3. Report Articoli.xls/xlsx (OBBLIGATORIO)", font=("Segoe UI", 10, "bold"), width=70, height=2, bg="#e74c3c", fg="white")
btn_xls.pack(pady=8)
lbl_xls = tk.Label(frame, text="Nessun file Excel selezionato", fg="#95a5a6", wraplength=850)
lbl_xls.pack(pady=(2,20))

progress = ttk.Progressbar(frame, mode='determinate', length=850)
progress.pack(pady=10)

log_frame = tk.Frame(frame, bg="white", relief="sunken", bd=1)
log_frame.pack(pady=10, fill="both", expand=True)
log_text = tk.Text(log_frame, height=18, font=("Consolas", 9), bg="#fdfdfd", fg="#2c3e50")
log_text.pack(side="left", fill="both", expand=True, padx=5, pady=5)
scrollbar = tk.Scrollbar(log_frame, command=log_text.yview)
scrollbar.pack(side="right", fill="y")
log_text.config(yscrollcommand=scrollbar.set)

footer = tk.Label(root, text=f"Output → {output_folder} | DB → Database_Generatore.db | Log → RMA_RitornoGiacenza_Log.txt",
                  font=("Segoe UI", 8), bg="#f0f4f8", fg="#95a5a6")
footer.pack(side="bottom", pady=15)

path_rma = path_fr = path_xls = None
logger = None
btn_avvia = None

# ========================
# FUNZIONI DI SUPPORTO
# ========================
def invia_email_smtp(filepath):
    msg = MIMEMultipart()
    msg['From'] = "atssegnalazioni@gmail.com"
    msg['To'] = "dizzo@atsgruppo.eu"
    msg['Subject'] = f"RMA Da Definire - {datetime.now():%d/%m/%Y}"
    with open(filepath, "rb") as f:
        part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
        msg.attach(part)
    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("atssegnalazioni@gmail.com", "xxx")
            server.send_message(msg)
        print("Email Da Definire inviata")
    except Exception as e:
        print(f"Errore email: {e}")

def write_dtw(data_list, path, header_sap, columns):
    if not data_list: return
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(",".join(header_sap) + "\n")
        f.write(",".join(columns) + "\n")
        pd.DataFrame(data_list, columns=columns).to_csv(f, index=False, header=False, lineterminator="\n")
# ========================
# ELABORAZIONE - VERSIONE DEFINITIVA 100% STABILE
# ========================
def avvia_elaborazione():
    global path_rma, path_fr, path_xls, logger
    if not path_fr or not path_xls:
        messagebox.showerror("Errore", "FR.CSV e Report Articoli sono obbligatori!")
        return

    logger = GUILogger(log_text)
    sys.stdout = logger
    log_text.delete(1.0, tk.END)

    def run():
        conn = None
        try:
            print("="*60)
            print("AVVIO ELABORAZIONE RMA RITORNO IN GIACENZA")
            print(f"Data/Ora: {datetime.now():%Y-%m-%d %H:%M:%S}")
            print(f"File Excel  : {os.path.basename(path_xls)}")
            print(f"File FR.csv : {os.path.basename(path_fr)}")
            print(f"File RMA.csv: {os.path.basename(path_rma) if path_rma else 'NON SELEZIONATO (opzionale)'}")
            print("="*60)

            conn = sqlite3.connect(db_path)
            storico_table = "StoricoOrdiniCaricati_RMA"
            conn.execute(f'''CREATE TABLE IF NOT EXISTS "{storico_table}" 
                            ("Riferimento" TEXT PRIMARY KEY, "TimeStamp" TEXT, "Tipo" TEXT, "SerialeUsato" TEXT)''')
            conn.commit()

            # Lettura storico
            storico_gia_fatti = pd.read_sql_query(f'SELECT Riferimento FROM "{storico_table}"', conn)["Riferimento"].astype(str).tolist()
            print(f"Ordini già caricati nello storico: {len(storico_gia_fatti)}")

            # Conversione depositi
            conv_depositi = pd.read_sql_query('SELECT * FROM "Conversione Depositi VLT"', conn).fillna("")
            conv_depositi["VLT"] = conv_depositi["VLT"].astype(str).str.strip().str.upper()
            print(f"Depositi mappati nel DB: {len(conv_depositi)}")

            progress['value'] = 10
            root.update()

            # 1. EXCEL
            print("\n1. Lettura Report Articoli Excel...")
            df_giacenza = pd.read_excel(path_xls, dtype=str).fillna("")
            df_giacenza.columns = [col.strip() for col in df_giacenza.columns]  # pulizia colonne Excel
            print(f"   → Righe totali Excel: {len(df_giacenza)}")

            df_giacenza["Stato"] = df_giacenza["Stato"].astype(str).str.strip()
            df_giacenza["PoNr"] = df_giacenza["PoNr"].astype(str).str.strip()
            df_giacenza["MaterialID"] = df_giacenza["MaterialID"].astype(str).str.strip()

            giacenza_usato = df_giacenza[df_giacenza["Stato"] == "Usato"].copy()
            print(f"   → Righe con Stato = 'Usato': {len(giacenza_usato)}")

            if len(giacenza_usato) == 0:
                print("   ATTENZIONE: Nessuna riga 'Usato' trovata → niente da elaborare!")
            progress['value'] = 25
            root.update()

            # 2. RMA.CSV (opzionale) - MERGE 1:1 SICURO
            matched_rma = pd.DataFrame()
            if path_rma:
                print("\n2. Elaborazione RMA.CSV (automatico)...")
                rma_path = path_rma
                if path_rma.endswith(".gz"):
                    tmp = os.path.join(base_path, "rma_temp.csv")
                    with gzip.open(path_rma, "rb") as f_in, open(tmp, "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
                    rma_path = tmp

                df_rma = pd.read_csv(rma_path, sep=r'\s*\|\s*', engine="python",
                                   dtype=str, keep_default_na=False, quoting=3).fillna("")
                df_rma.columns = [col.strip() for col in df_rma.columns]
                df_rma = df_rma.rename(columns=lambda x: x.strip())
            
                print(f"   → Colonne RMA.csv pulite: {len(df_rma.columns)}")

                print(f"   → Righe totali RMA.CSV: {len(df_rma)}")
                df_rma = df_rma[df_rma["stato"].str.strip() == "TO_SHIP_FROM_CW"]
                print(f"   → Dopo filtro TO_SHIP_FROM_CW: {len(df_rma)}")

                def parse_date(d):
                    if not d: return None
                    try:
                        return datetime.strptime(d.strip().upper(), "%d-%b-%y").strftime("%d/%m/%Y")
                    except:
                        return None

                df_rma["data_dt"] = pd.to_datetime(
                    df_rma["data_apertura"].apply(parse_date),
                    format="%d/%m/%Y", errors="coerce"
                )

                oggi = datetime.now().date()
                ieri = oggi - timedelta(days=1)
                df_rma = df_rma[(df_rma["data_dt"].dt.date >= ieri) & (df_rma["data_dt"].dt.date <= oggi)]
                print(f"   → Dopo filtro data ieri-oggi: {len(df_rma)}")

                if not df_rma.empty:
                    df_rma["material"] = df_rma["material"].str.strip()

                    # MERGE 1:1 CORRETTO - NESSUN DUPLICATO SERIALE
                    giacenza_disponibile = giacenza_usato.copy()
                    matched_list = []

                    for _, rma_row in df_rma.iterrows():
                        material = rma_row["material"]
                        candidates = giacenza_disponibile[giacenza_disponibile["MaterialID"] == material]
                        if not candidates.empty:
                            excel_row = candidates.iloc[0]
                            combined = pd.concat([rma_row, excel_row])
                            matched_list.append(combined)
                            giacenza_disponibile = giacenza_disponibile.drop(excel_row.name)

                    matched_rma = pd.DataFrame(matched_list).reset_index(drop=True) if matched_list else pd.DataFrame()
                    print(f"   → Match RMA trovati (1:1 sicuro): {len(matched_rma)}")
                    giacenza_usato = giacenza_disponibile.copy()  # aggiorna per flusso manuale
                else:
                    print("   Nessuna riga RMA valida dopo i filtri")
            else:
                print("\n2. RMA.CSV non selezionato → flusso automatico saltato")

            progress['value'] = 50
            root.update()

            # 3. FR.CSV (manuale)
            print("\n3. Elaborazione FR.CSV (manuale)...")
            fr_path = path_fr
            if path_fr.endswith(".gz"):
                tmp = os.path.join(base_path, "fr_temp.csv")
                with gzip.open(path_fr, "rb") as f_in, open(tmp, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
                fr_path = tmp

            df_fr = pd.read_csv(fr_path, sep=r'\s*\|\s*', engine="python",
                              dtype=str, keep_default_na=False, quoting=3).fillna("")
            df_fr.columns = [col.strip() for col in df_fr.columns]
            print(f"   → Righe totali FR.CSV: {len(df_fr)}")
            df_fr["fr_id"] = df_fr["fr_id"].astype(str).str.strip()

            giacenza_manuale = giacenza_usato.copy()
            mask_len = giacenza_manuale["PoNr"].str.len() <= 6
            mask_notempty = giacenza_manuale["PoNr"].str.strip() != ""
            mask_vodafone = giacenza_manuale["Fornitore/Mittente"].astype(str)\
                                                             .str.upper()\
                                                             .str.contains("VODAFONE")
            giacenza_manuale = giacenza_manuale[mask_len & mask_notempty & ~mask_vodafone]

            print(f"   → Righe Excel disponibili per manuale "
                  f"(PoNr ≤6, non vuoto e senza Vodafone): {len(giacenza_manuale)}")

            matched_fr = df_fr.merge(giacenza_manuale, left_on="fr_id", right_on="PoNr", how="inner")
            print(f"   → MATCH FR trovati: {len(matched_fr)}")

            progress['value'] = 75
            root.update()

            # 4. CREAZIONE ORDINI
            print("\n4. Creazione ordini SAP...")
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ordr_out = os.path.join(output_folder, f"ORDR_RMA_RitornoGiacenza_{timestamp}.csv")
            rdr1_out = os.path.join(output_folder, f"RDR1_RMA_RitornoGiacenza_{timestamp}.csv")
            da_definire_out = os.path.join(output_folder, f"RMA_Da_Definire_{timestamp}.csv")

            ordr_list = []
            rdr1_list = []
            da_definire_list = []
            docnum = 10001
            progressivo_manuale = 1

            def crea_riga(row, tipo, riferimento, u_po):
                nonlocal docnum
                if str(riferimento) in storico_gia_fatti:
                    print(f"   → Salto {riferimento} (già caricato)")
                    return

                depot_key = "depot_destinazione" if tipo == "RMA_AUTO" else "depot_origine"
                depot = str(row.get(depot_key, "")).strip().upper()
                conv = conv_depositi[conv_depositi["VLT"] == depot]
                shipto = conv.iloc[0]["nome_dtw"] if not conv.empty else "NON DEFINITO"
                
              # FIX FINALE: trova fail_rep_id anche se ha spazi o ; nel nome colonna
                fail_rep_value = None
                for col_name in row.index:
                    if "fail_rep_id" in col_name.lower().replace(" ", "").replace(";", ""):
                        fail_rep_value = row[col_name]
                        break
                
                ref_fr = str(fail_rep_value).strip().split(";")[0].strip() if pd.notna(fail_rep_value) else ""
                if not ref_fr or ref_fr.lower() in ["", "none", "null", "nan", "na"]:
                    ref_fr = str(riferimento).strip()

                errors = []
                if shipto == "NON DEFINITO":
                    errors.append(f"Deposito non mappato: {depot}")

                ordr = {c: "" for c in ordr_columns}
                ordr.update({
                    "DocNum": docnum, "DocType": "dDocument_Items",
                    "DocDate": datetime.today().strftime("%Y%m%d"),
                    "DocDueDate": datetime.today().strftime("%Y%m%d"),
                    "CardCode": "C000021", "NumAtCard": u_po, "Series": 237,
                    "ShipToCode": "" if shipto == "NON DEFINITO" else shipto,
                    "TaxDate": datetime.today().strftime("%Y%m%d"),
                    "Project": "FLM", "U_Tipo": "RMA",
                    "Comments": f"Ritorno in Giacenza FR: {ref_fr}"
                })

                rdr1 = {c: "" for c in rdr1_columns}
                rdr1.update({
                    "ParentKey": docnum, "LineNum": 0,
                    "ItemCode": row["Codice articolo"],
                    "Dscription": row["Descrizione articolo"],
                    "Quantity": 1, "WhsCode": "CE71-SHP",
                    "Project": "FLM",
                    "U_PartNumber": str(row.get("Part Number", row.get("PartNumber", ""))).strip(),
                    "U_PO": riferimento, "U_CDC": "FLM", "Price": 0,
                    "U_IDScheda": row["Seriale"], "U_Seriale": row["Seriale"],
                    "SubCatNum": row["MaterialID"]
                })

                if errors:
                    print(f"   DA DEFINIRE → {errors[0]} | Rif: {riferimento}")
                    rdr1["Motivo_Errore"] = " | ".join(errors)
                    da_definire_list.append({**ordr, **rdr1})
                else:
                    ordr_list.append(ordr)
                    rdr1_list.append(rdr1)
                    seriale = str(row.get("Seriale", "")).strip()
                    if seriale.lower() in ["nan", "none", ""]: 
                        seriale = ""
                    conn.execute(f'INSERT OR IGNORE INTO "{storico_table}" VALUES (?,?,?,?)',
                                 (str(riferimento), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), tipo, seriale))
                    conn.commit()
                    storico_gia_fatti.append(str(riferimento))
                    print(f"   Ordine {docnum} creato → NumAtCard={u_po} | U_PO={riferimento} | Reintegro_FR={ref_fr}")
                docnum += 1

            # RMA automatici
            for _, row in matched_rma.iterrows():
                po = str(row.get("PoNr", "")).strip()
                rif = po if po and po != "nan" and po != "" else str(row.get("id_rma", "NO_ID")).strip()
                u_po = str(row.get("fail_rep_id", row.get("id_rma", "NO_ID"))).strip()
                crea_riga(row, "RMA_AUTO", rif, u_po)

            # FR manuali
            for _, row in matched_fr.iterrows():
                rif = str(row["PoNr"]).strip()
                u_po = f"RMA{progressivo_manuale:05d}"
                crea_riga(row, "RMA_MANUALE", rif, u_po)
                progressivo_manuale += 1

            # Scrittura finale
            print(f"\nOrdini validi creati      : {len(ordr_list)}")
            print(f"Righe da definire         : {len(da_definire_list)}")
            write_dtw(ordr_list, ordr_out, ordr_header_sap, ordr_columns)
            write_dtw(rdr1_list, rdr1_out, rdr1_header_sap, rdr1_columns)

            if da_definire_list:
                cols = list(da_definire_list[0].keys())
                pd.DataFrame(da_definire_list, columns=cols).to_csv(da_definire_out, index=False, sep=",", encoding="utf-8-sig")
                print(f"Generato file Da Definire → {da_definire_out}")
                invia_email_smtp(da_definire_out)

            print("\n" + "="*60)
            print("ELABORAZIONE COMPLETATA CON SUCCESSO!")
            print(f"ORDR → {ordr_out}")
            print(f"RDR1 → {rdr1_out}")
            print("="*60)

            progress['value'] = 100
            messagebox.showinfo("Finito!", f"Tutto fatto!\n\nFile in:\n{output_folder}")

        except Exception as e:
            print(f"\nERRORE GRAVE: {e}")
            import traceback
            traceback.print_exc()
            messagebox.showerror("ERRORE", str(e))
        finally:
            if conn: conn.close()

    Thread(target=run, daemon=True).start()
# ========================
# PULSANTI E CONTROLLO AVVIO
# ========================
def aggiorna_avvia():
    global btn_avvia
    if path_fr and path_xls and btn_avvia is None:
        btn_avvia = tk.Button(frame, text="AVVIA ELABORAZIONE", font=("Segoe UI", 14, "bold"), width=50, height=2,
                              bg="#27ae60", fg="white", command=avvia_elaborazione)
        btn_avvia.pack(pady=20)
    elif (not path_fr or not path_xls) and btn_avvia:
        btn_avvia.destroy()
        btn_avvia = None

def scegli_rma():
    global path_rma
    f = filedialog.askopenfilename(filetypes=[("CSV", "*.csv *.csv.gz")])
    if f:
        path_rma = f
        lbl_rma.config(text=f"RMA: {os.path.basename(f)}", fg="#27ae60")

def scegli_fr():
    global path_fr
    f = filedialog.askopenfilename(filetypes=[("CSV", "*.csv *.csv.gz")])
    if f:
        path_fr = f
        lbl_fr.config(text=f"FR: {os.path.basename(f)}", fg="#27ae60")
        aggiorna_avvia()

def scegli_xls():
    global path_xls
    f = filedialog.askopenfilename(filetypes=[("Excel", "*.xls *.xlsx")])
    if f:
        path_xls = f
        lbl_xls.config(text=f"Excel: {os.path.basename(f)}", fg="#27ae60")
        aggiorna_avvia()

btn_rma.config(command=scegli_rma)
btn_fr.config(command=scegli_fr)
btn_xls.config(command=scegli_xls)

root.mainloop()